# Databricks notebook source
# MAGIC %run ./VersionedLibraries

# COMMAND ----------

# Imports
from collections import namedtuple
from pyspark.sql import *
from pyspark.sql.functions import *
import datetime, json, math, uuid

# COMMAND ----------

# MAGIC %run ./common_functions

# COMMAND ----------

# DO NOT CHANGE - Call from Test/CallNotebooks with desired values, or call from ADF
try:
  _asOfDate = dbutils.widgets.get('_asOfDate')
  _period = dbutils.widgets.get('_period')
  _region = dbutils.widgets.get('_region')
  _curationName = dbutils.widgets.get('_curationName')
  try:
    _getAdjustedDF = dbutils.widgets.get('_getAdjustedDF')
  except:
    _getAdjustedDF = "N"

except:
  raise Exception(CONST_EXCEPTION_MUST_RUN_FROM_JOB_OR_OTHER_NOTEBOOK)


# COMMAND ----------

# Get GDF Context
try:
  gdfContext = GetGdfContext('DALFI_Ddf_Curation', _asOfDate, _period, _region, get_adjusted_df=_getAdjustedDF)
except:
  raise

# COMMAND ----------

try:
  outputDf = gdfContext.get_df(_curationName).df
except:
  raise