# Databricks notebook source
gdfVersion = '1.6.607'

# COMMAND ----------

def installLibraries(): 
  # cp command only for POC env, please do not use in DEV or above
  dbutils.library.install('dbfs:/FileStore/jars/gdf.metlife-' + gdfVersion + '-py3-none-any.whl')
  dbutils.library.restartPython()

# COMMAND ----------

import dff
try:
  print("GDF Version BEFORE calling installLibraries(): " + dff.__version__)
except:
  print("GDF Version BEFORE calling installLibraries(): Older Version")

# COMMAND ----------

installLibraries()

# COMMAND ----------

import dff
try:
  print("GDF Version AFTER calling installLibraries(): " + dff.__version__)
except:
  print("GDF Version AFTER calling installLibraries(): Older Version")