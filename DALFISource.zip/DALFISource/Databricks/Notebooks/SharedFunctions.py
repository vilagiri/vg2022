# Databricks notebook source
import json
from collections import namedtuple
from pyspark.sql import *
from pyspark.sql.functions import * #array, col, collect_list, concat, explode, explode_outer, lit, struct
from pyspark.sql.types import *
from dff.dfutils import timeit

# COMMAND ----------

class ReferenceFunctions(object):
  """ 
    -----------------------
    Class:
    -----------------------
      ReferenceFunctions
        Holds functions that return fields from CodeReference frame based on input parameters
    -----------------------
    Functions:
    -----------------------
      GetCodeReferenceLookupDetails(cdrfDomainName)
        Takes a asOfDate through commonStructure and cdrfDomainName (e.g. CountryOfRisk) as input and returns dataframe containing type, code and name/description
    -----------------------
  """
  def __init__(self):
    pass
  
  @staticmethod
  def GetCodeReferenceExploded_Internal(commonStructure, cdrfDomainName):
    """
    -----------------------
    Name
    -----------------------
      GetCodeReferenceExploded_Internal
    -----------------------
    Description
    -----------------------
      This is internal function limited to this class only called by GetCodeReferenceLookupDetails method, not to be called from outside the class. It takes AsOfDate from common structure, code reference type as an input and   returns frame with exploded column records from code reference (cdrf) file by code reference name
      Dependent Fields (not including _primaryKeys):
        (N/A)
      Output Fields (not including _primaryKeys):
        Returns fields from CDRF file based on code reference domain name being queried for
    -----------------------
    Parameters
    -----------------------
      commonStructure:  A struct that defines common variables, such as AsOfDate     
      cdrfDomainName:  A variable providing code reference domain name, example, "AccrualType"      
    -----------------------
    Returns
    -----------------------
      resultsDf:  A dataframe with only the Output Fields listed above (including _primaryKeys)
    """
    
    ''' 
    -----------------------
    BEGIN STEP 1:  INITIALIZING VARIABLES WHICH WILL BE REUSED
    -----------------------
    '''
    ''' 
    -----------------------
    END  STEP 1
    -----------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 1: JOIN AND MINIMIZE
    ------------------------
    '''
    try:
        gdfContext = GetGdfContext('cdrf',commonStructure.AsOfDate,'d','glob')
        mastCDRFDf = gdfContext.get_df('mast_cdrf_df').df
        '''
        ------------------------
        END STEP 1
        ------------------------
        '''

        '''
        ------------------------
        BEGIN STEP 2: BUSINESS-LOGIC
        ------------------------
        '''
        #Minimize code reference frame to cdrfDomainName parameter
        minMastCDRFDf = mastCDRFDf.filter("ReferenceDomainName == '{}'".format(cdrfDomainName)).select("ReferenceDomainName","ReferenceDomainFields").withColumn("ReferenceDomainFields1", explode("ReferenceDomainFields")).select("ReferenceDomainName", "ReferenceDomainFields1")
        #Select exploded data, store in frame, this includes fields from other reference domain name (cdrfDomainName) too
        minMastCDRFExpDf = minMastCDRFDf.select("ReferenceDomainName","ReferenceDomainFields1.*")    
        #Exclude null columns from other cdrfDomainName and store fields that are applicable to current cdrfDomainName only in final frame
        minMastCDRFExpNotNullDf = spark.createDataFrame(minMastCDRFExpDf.toPandas().dropna(how = "all",axis=1))
        '''
        ------------------------
        END STEP 2
        ------------------------
        '''

        '''
        ------------------------
        BEGIN STEP 3: OUTPUT
        ------------------------
        '''        
        #create structure df
        rf = ReferenceFunctions()
        resultsDf = rf.GetCodeReferenceOptionalColumnWithSchema(commonStructure, cdrfDomainName, minMastCDRFExpNotNullDf)
        return resultsDf
    except Exception as e:
        raise Exception("ERROR: CDRF lookup failed for domain : {}  with the exception : {}".format(cdrfDomainName, e))
    '''
    ------------------------
    END STEP 3
    ------------------------
    '''    
    
  @staticmethod
  @timeit
  def GetCodeReferenceOptionalColumnWithSchema(commonStructure, cdrfDomainName, ratingCdrfDf):
      import datetime
      gdfContext = GetGdfContext('cdrf',commonStructure.AsOfDate,'d','glob')  
      dfname = "mast_cdrf_df"
      as_of_date = commonStructure.AsOfDate
      reg_hndlr = gdfContext.registry
      file_system_root = "/" + gdfContext.environment.get_file_system()
      #Added below part to support schema atTime implementation 
      latest_atTime = gdfContext._find_potential_idz_timestamp(dfname,as_of_date,'glob','d',  datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S") )
      context = dict()
      context['RunTime'] = latest_atTime.strftime("%Y-%m-%d %H:%M:%S")

      from dff.dfsnapshot import SchemaFolder
      from dff.dfjsonparser import PySparkSchemaInference, JSONSchemaParser
      json_schema_def = {'data_set_key': 'definitions',
       'schema_file': 'CodeReference.json',
       'file_type': 'json'}
      json_schema_path = reg_hndlr.get_json_schema_path(dfname=dfname)
      json_schema_def_file = json_schema_def.get("schema_file","")
      json_schema_data_set_keys = json_schema_def.get("data_set_key","").split("/")
      schema_obj = SchemaFolder(json_schema_path, json_schema_def_file, as_of_date, context = context)
      schema_file_path = json_schema_path + "/" + schema_obj.get_latest_appropriate_schema_file() if json_schema_path.startswith(file_system_root) else \
              file_system_root + json_schema_path + "/" + schema_obj.get_latest_appropriate_schema_file()
      print(schema_file_path)
      with open(schema_file_path) as sch:
          schema = json.load(sch)

      print("Schema file to infer schema for {} reference category : {}".format(cdrfDomainName , schema_file_path))
      column_reference_resolved_schema_def = JSONSchemaParser(as_of_date=as_of_date, file_system_root=file_system_root
      ).json_schema_reference_resolver(schema_path=schema_file_path, schema=schema, 
      schema_item_root_def=json_schema_data_set_keys, attribute=cdrfDomainName)
      column_reference_resolved_schema_def.update({"type": "object"})
      final_schema_obj = PySparkSchemaInference(cdrfDomainName, column_reference_resolved_schema_def).schema_conversion()
      print("PySparkSchema for column {}  is : {}".format(cdrfDomainName, final_schema_obj))
      for elem in final_schema_obj:
        if elem.name not in ratingCdrfDf.columns:
          ratingCdrfDf = ratingCdrfDf.withColumn(elem.name, lit(None).cast(elem.dataType))
      return ratingCdrfDf

  @staticmethod
  def GetCodeReferenceLookupDetails(commonStructure, cdrfDomainName):
    """
    -----------------------
    Name
    -----------------------
      GetCodeReferenceLookupDetails
    -----------------------
    Description
    -----------------------
      Takes code reference domain name (cdrfDomainName - e.g. AccrualType) as input parameter, returns list of code reference records with fields listed below, this function internally calls GetCodeReferenceExploded_Internal
      from this class for exploded records retrieval by reference domain name
      Dependent Fields (not including _primaryKeys):
        (N/A)
      Output Fields (not including _primaryKeys):
          Returns fields from CDRF file based on code reference domain name being queried for
    -----------------------
    Parameters
    -----------------------
      commonStructure:  A struct that defines common variables, such as AsOfDate     
      cdrfDomainName:  A variable providing code reference domain name, example, "AccrualType"
    -----------------------
    Returns
    -----------------------
      resultsDf:  A dataframe with only the Output Fields listed above (including _primaryKeys)
    """
    
    ''' 
    -----------------------
    BEGIN STEP 1:  INITIALIZING VARIABLES WHICH WILL BE REUSED
    -----------------------
    '''

    ''' 
    -----------------------
    END  STEP 1
    -----------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 1: JOIN AND MINIMIZE
    ------------------------
    '''
    
    '''
    ------------------------
    END STEP 1
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 2: BUSINESS-LOGIC
    ------------------------
    '''
    #create structure df
    rf = ReferenceFunctions()
    minMastCDRFExpDf = rf.GetCodeReferenceExploded_Internal(commonStructure, cdrfDomainName)
    '''
    ------------------------
    END STEP 2
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 3: OUTPUT
    ------------------------
    '''
    resultsDf = minMastCDRFExpDf
    return resultsDf
    '''
    ------------------------
    END STEP 3
    ------------------------
    '''
    
  @staticmethod
  def GetStandardCodeLookupDetails(commonStructure, stdcDomainName):
    """
    -----------------------
    Name
    -----------------------
      GetStandardCodeLookupDetails
    -----------------------
    Description
    -----------------------
      Takes code reference type (stdcDomainName - e.g. CountryOfRisk) as input parameter, returns list of standard code records with fields listed below
      Dependent Fields (not including _primaryKeys):
        (N/A)
      Output Fields (not including _primaryKeys):
JC - PENDING
        Name, Code (primary key)
        ActiveInd
        Description
    -----------------------
    Parameters
    -----------------------
      commonStructure:  A struct that defines common variables, such as AsOfDate     
      stdcDomainName:  Input parameter field that highlights which standard code type records to be returned
    -----------------------
    Returns
    -----------------------
      resultsDf:  A dataframe with only the Output Fields listed above (including _primaryKeys)
    """
    
    ''' 
    -----------------------
    BEGIN STEP 1:  INITIALIZING VARIABLES WHICH WILL BE REUSED
    -----------------------
    '''
    ''' 
    -----------------------
    END  STEP 1
    -----------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 1: JOIN AND MINIMIZE
    ------------------------
    '''
    gdfContext = GetGdfContext('stdc',commonStructure.AsOfDate,'d','glob')
    mastSTDCDf=gdfContext.get_df('mast_stdc_df').df
    #display(mastSTDCDf.select("Name").distinct())    
    minMastSTDCDf=mastSTDCDf.where(col('Name')==stdcDomainName)
    #Get exploded dataframe with STDC data
    expMinMastSTDCDf=GetExplodedDf(minMastSTDCDf,['Name','CodeDesc'],'CodeDesc')

    '''
    ------------------------
    END STEP 1
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 2: BUSINESS-LOGIC
    ------------------------
    '''

    '''
    ------------------------
    END STEP 2
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 3: OUTPUT
    ------------------------
    '''
    resultsDf = expMinMastSTDCDf
    return resultsDf
    '''
    ------------------------
    END STEP 3
    ------------------------
    '''    

      
  @staticmethod
  def GetCountryLookupDetails(commonStructure):
    """
    -----------------------
    Name
    -----------------------
      GetCountryLookupDetails
    -----------------------
    Description
    -----------------------
      Takes AsOfDate from common structure as an input and returns frame with list of country records with fields listed below
      Dependent Fields (not including _primaryKeys):
        (N/A)
      Output Fields (not including _primaryKeys):
        ActiveFlag:string
        CountryCode:string (_primaryKey)
        CountryName:string
        EmergingMarketInd:string
        ISOCountryAlpha2Code:string
        ISOCountryAlpha3Code:string
        ISOCountryEnglishDesc:string
        ISOCountryNumericCode:string
        MetLifeGeographicRegionCode:string
        MetLifeGeographicSubRegionCode:string
        OfficialCurrencyCode:string
        _mast_cnty_df_AsOfDate:string
        _mast_cnty_df_Period:string
        _mast_cnty_df_Region:string
        _mast_cnty_df_RunTime:string
        _corrupt_record:string
        _corrupt_record_reason:string
    -----------------------
    Parameters
    -----------------------
      commonStructure:  A struct that defines common variables, such as AsOfDate     
    -----------------------
    Returns
    -----------------------
      resultsDf:  A dataframe with only the Output Fields listed above (including _primaryKeys)
    """
    
    ''' 
    -----------------------
    BEGIN STEP 1:  INITIALIZING VARIABLES WHICH WILL BE REUSED
    -----------------------
    '''
    ''' 
    -----------------------
    END  STEP 1
    -----------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 1: JOIN AND MINIMIZE
    ------------------------
    '''
    gdfContext = GetGdfContext('cnty',commonStructure.AsOfDate,'d','glob')
    mastCntyDf=gdfContext.get_df('mast_cnty_df').df
    '''
    ------------------------
    END STEP 1
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 2: BUSINESS-LOGIC
    ------------------------
    '''

    '''
    ------------------------
    END STEP 2
    ------------------------
    '''
    
    '''
    ------------------------
    BEGIN STEP 3: OUTPUT
    ------------------------
    '''
    resultsDf = mastCntyDf
    return resultsDf
    '''
    ------------------------
    END STEP 3
    ------------------------
    '''

# COMMAND ----------

def GetEffectiveInterestSchedule (asmtDf):
  
  # After CR 103421
  # Filter InterestSchedule for following cases(CR 103421):
  # 0 --> Erroneous patterns/NULL valued InterestSchedules
  # 1 --> AsOfDate lies between  Min(StartDate), max(EndDate) ==> AsOfDate >= min(StartDate) & AsOfDate <= max(EndDate)
  # 1.a --> AsOfDate >= StartDate & AsOfDate < EndDate
  # 1.b --> AsOfDate < max(EndDate) ==> StartDate_GreaterThanOrEqualTo_AsOfDate --> effIntSched
  # 2 --> AsOfDate > max(EndDate) --> then pick max(EndDate) --> effIntSched
  # 3 --> AsOfDate < min(StartDate) --> then pick min(StartDate) --> effIntSched

  laprDf_Int0 = asmtDf.select('AsOfDate', 'MetLifeAssetID', 'InterestSchedule').dropDuplicates()

  interestScheduleDf = GetExplodedDf2(laprDf_Int0, ['MetLifeAssetID', 'AsOfDate', 'InterestSchedule'], 'InterestSchedule') \
    .dropDuplicates() \
    .withColumnRenamed('MetLifeAssetID', 'IntSched_ChildMetLifeAssetID') \
    .select('AsOfDate', 'EndDate', 'IndexSpread', 'InterestReferencedIndexID', 'IntSched_ChildMetLifeAssetID', 'MetLifeInterestTypeCode', 'StartDate')

  # Case 0 : NULL valued as interestSchedule 0r and of  startDate and EndDate is NULL
  null_IS_df = laprDf_Int0.filter("InterestSchedule is NULL") \
    .withColumn('IntSched_ChildMetLifeAssetID', col('MetLifeAssetID')) \
    .withColumn('IntSched_MetLifeInterestTypeCode', lit(None)) \
    .withColumn('IntSched_InterestReferencedIndexID', lit(None)) \
    .withColumn('IntSched_IndexSpread', lit(None)) \
    .withColumn('IntSched_StartDate', lit(None)).withColumn('IntSched_EndDate', lit(None))

  # Finding Anomaly patterns of interestSchedule
  filter_condition_Int0 = ["{} is NULL or {} is NULL".format('StartDate','EndDate')]

  anomaly_IS_df = interestScheduleDf.filter(filter_condition_Int0[0]).withColumnRenamed('MetLifeInterestTypeCode', 'IntSched_MetLifeInterestTypeCode').withColumnRenamed('InterestReferencedIndexID', 'IntSched_InterestReferencedIndexID').withColumnRenamed('IndexSpread', 'IntSched_IndexSpread').withColumnRenamed('StartDate', 'IntSched_StartDate').withColumnRenamed('EndDate', 'IntSched_EndDate').withColumn('IntSched_MetLifeInterestTypeCode', lit(None)).withColumn('IntSched_InterestReferencedIndexID', lit(None)).withColumn('IntSched_IndexSpread', lit(None)).withColumn('IntSched_StartDate', lit(None)).withColumn('IntSched_EndDate', lit(None))

  laprDf_Int1 = laprDf_Int0.join(anomaly_IS_df.drop(col('AsOfDate')), laprDf_Int0.MetLifeAssetID == anomaly_IS_df.IntSched_ChildMetLifeAssetID, how='inner').dropDuplicates()

  # UNION for finding original null valued records
  inCorrectInteresScheduleDf = null_IS_df.union(laprDf_Int1)

  #   # UNION for case 0 
  determined_effIntSchedList0 = inCorrectInteresScheduleDf.select('IntSched_ChildMetLifeAssetID').dropDuplicates().rdd.flatMap(lambda x: x).collect()

  #Computations for cases 1,1.a,2 and 3  
  filter_condition_Int1 = ["{} is not NULL and {} is not NULL".format('StartDate','EndDate')]
  undetermined_Int1 = interestScheduleDf.filter(filter_condition_Int1[0]) if determined_effIntSchedList0 else interestScheduleDf
  exprs = [min("StartDate").alias("min_start_date"), max("EndDate").alias("max_end_date")]
  interestScheduleDfGBy = undetermined_Int1.groupBy('AsOfDate', 'IntSched_ChildMetLifeAssetID').agg(*exprs)
  data_joined = undetermined_Int1.join(interestScheduleDfGBy, ['AsOfDate', 'IntSched_ChildMetLifeAssetID'])

  withEffIntSched_Int1 = data_joined.withColumn("effIntSched",F.when(
    ((to_date(data_joined["AsOfDate"], sql_standard_date_format) >= to_date(data_joined["StartDate"], sql_standard_date_format))
    & (to_date(data_joined["AsOfDate"], sql_standard_date_format) < to_date(data_joined["EndDate"], sql_standard_date_format)))
    |((to_date(data_joined["AsOfDate"], sql_standard_date_format) < to_date(data_joined["min_start_date"], sql_standard_date_format)) 
    & (to_date(data_joined["min_start_date"], sql_standard_date_format) == to_date(data_joined["StartDate"], sql_standard_date_format)))
    |((to_date(data_joined["AsOfDate"], sql_standard_date_format) >= to_date(data_joined["max_end_date"], sql_standard_date_format)) 
    & (to_date(data_joined["max_end_date"], sql_standard_date_format) == to_date(data_joined["EndDate"], sql_standard_date_format)))
    , "Y"
  ).otherwise("N"))

  withEffIntSched_Int2 = withEffIntSched_Int1 \
    .filter("effIntSched == 'Y'") \
    .select('AsOfDate', 'EndDate', 'IndexSpread', 'InterestReferencedIndexID', 'IntSched_ChildMetLifeAssetID', 'MetLifeInterestTypeCode', 'StartDate') \
    .withColumnRenamed('MetLifeInterestTypeCode', 'IntSched_MetLifeInterestTypeCode') \
    .withColumnRenamed('InterestReferencedIndexID', 'IntSched_InterestReferencedIndexID') \
    .withColumnRenamed('IndexSpread', 'IntSched_IndexSpread').withColumnRenamed('StartDate', 'IntSched_StartDate') \
    .withColumnRenamed('EndDate', 'IntSched_EndDate')

  determined_effIntSchedList = withEffIntSched_Int2.select('IntSched_ChildMetLifeAssetID').rdd.flatMap(lambda x: x).collect()

  laprDf_Int2 = laprDf_Int0.join(withEffIntSched_Int2.drop(col('AsOfDate')), laprDf_Int0.MetLifeAssetID == withEffIntSched_Int2.IntSched_ChildMetLifeAssetID, how='inner').dropDuplicates()

  if determined_effIntSchedList:
    filter_condition_Int1.append("IntSched_ChildMetLifeAssetID not in ('{}') ".format("','".join(determined_effIntSchedList)))

  #Computations for cases 1.b
  filter_condition_Int2 = " and ".join(filter_condition_Int1)
  undetermined_Int2 = undetermined_Int1.filter(filter_condition_Int2).filter(to_date(undetermined_Int1["AsOfDate"], sql_standard_date_format) < to_date(undetermined_Int1["EndDate"], sql_standard_date_format))
  exprs = [min("StartDate").alias("min_start_date_ge_aod")]
  agg_undetermined = undetermined_Int2.groupBy('AsOfDate', 'IntSched_ChildMetLifeAssetID').agg(*exprs)
  undetermined_Int3 = undetermined_Int2.join(agg_undetermined, ['AsOfDate', 'IntSched_ChildMetLifeAssetID'])

  withEffIntSched_Int3 = undetermined_Int3 \
    .withColumn("effIntSched", F.when(
      ((to_date(undetermined_Int3["StartDate"], sql_standard_date_format) > to_date(undetermined_Int3["AsOfDate"], sql_standard_date_format))
      & (to_date(undetermined_Int3["StartDate"], sql_standard_date_format) == to_date(undetermined_Int3["min_start_date_ge_aod"], sql_standard_date_format))
      )  , "Y"
    ).otherwise("N"))

  withEffIntSched_Int4 = withEffIntSched_Int3 \
    .filter("effIntSched == 'Y'") \
    .select('AsOfDate', 'EndDate', 'IndexSpread', 'InterestReferencedIndexID', 'IntSched_ChildMetLifeAssetID', 'MetLifeInterestTypeCode', 'StartDate') \
    .withColumnRenamed('MetLifeInterestTypeCode', 'IntSched_MetLifeInterestTypeCode') \
    .withColumnRenamed('InterestReferencedIndexID', 'IntSched_InterestReferencedIndexID') \
    .withColumnRenamed('IndexSpread', 'IntSched_IndexSpread') \
    .withColumnRenamed('StartDate', 'IntSched_StartDate') \
    .withColumnRenamed('EndDate', 'IntSched_EndDate')

  #Joining final dataset with all cases resolved to the parent loan
  laprDf_Int3 = laprDf_Int0.join(withEffIntSched_Int4.drop(col('AsOfDate')), laprDf_Int0.MetLifeAssetID == withEffIntSched_Int4.IntSched_ChildMetLifeAssetID, how='inner').dropDuplicates()

  final_Int1 = laprDf_Int2.union(laprDf_Int3)

  # Joining NULL valued InterestSchedule with inferred InterestSchedule

  initial_Int1 = set(laprDf_Int0.select('MetLifeAssetID').rdd.flatMap(lambda x: x).collect())
  final_Int2 = set(final_Int1.select('MetLifeAssetID').rdd.flatMap(lambda x: x).collect())
  null_valued_lapr_df = inCorrectInteresScheduleDf.filter("MetLifeAssetID in ('{}') ".format("','".join(initial_Int1 - final_Int2)))

  effIntSched = final_Int1.union(null_valued_lapr_df)
  return effIntSched

# COMMAND ----------

def GetEffectiveInterestRateResetSchedule( asmtDf ):
  
  irrScheduleDf_Int1 = GetExplodedDf2(asmt, ['MetLifeAssetID'], 'InterestRateResetSchedule') \
    .withColumnRenamed('MetLifeAssetID', 'Irr1MetLifeAssetID') \
    .withColumnRenamed('InterestRateEffectiveDate', 'Irr1InterestRateEffectiveDate')

  irrScheduleDf_Int2 = irrScheduleDf_Int1.groupBy(irrScheduleDf_Int1.Irr1MetLifeAssetID).agg(max('Irr1InterestRateEffectiveDate').alias('Irr1InterestRateEffectiveDate'))

  irrScheduleDf_Int3 = irrScheduleDf_Int2 \
    .withColumnRenamed('Irr1MetLifeAssetID', 'Irr2MetLifeAssetID') \
    .withColumnRenamed('Irr1InterestRateEffectiveDate', 'Irr2InterestRateEffectiveDate')

  irrScheduleDf = irrScheduleDf_Int3.join(irrScheduleDf_Int1,
    (irrScheduleDf_Int3.Irr2MetLifeAssetID == irrScheduleDf_Int1.Irr1MetLifeAssetID) 
    & (irrScheduleDf_Int3.Irr2InterestRateEffectiveDate == irrScheduleDf_Int1.Irr1InterestRateEffectiveDate)
  ).withColumnRenamed('Irr2MetLifeAssetID', 'IrrSchedule_MetLifeAssetID').dropDuplicates()
  
  return irrScheduleDf