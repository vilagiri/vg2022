# Databricks notebook source
# MAGIC %md
# MAGIC This notebook is used to purge DDZ data for AsOfDate older than 40 days
# MAGIC 
# MAGIC Set ddz root path and number of days for which data needs to be retained using below variables

# COMMAND ----------

ddz_root_path = "dbfs:/mnt/data/inv/ddz"
days_to_purge = 40

# COMMAND ----------

from datetime import datetime, timedelta
from dateutil.parser import parse

# is_date function is used to check if a string value is a valid Date
# Returns whether the string can be interpreted as a date. 
def is_date(date_value):   
  try: 
    parse(date_value)
    return True

  except ValueError:
    return False

'''
List comprehension statement below is equal to

for each TargetEAICode in DDZ root folder
  for each QueryName folder in TargetEAICode
    if child item is a folder 
      and foldername is in 'date' format
      and foldername (asofdate) is less than days_to_purge from current date 
      then add path of this folder to the list of folders to delete
'''

asOfDateFolderList = [ item.path for targerteaicode in dbutils.fs.ls(ddz_root_path) for queryname in dbutils.fs.ls(targerteaicode.path) for item in dbutils.fs.ls(queryname.path) if (item.isDir() and is_date(item.name[:-1]) and parse(item.name[:-1]) < (datetime.today() - timedelta(days=days_to_purge))) ]

# Delete all AsOfDate folders which are < days_to_purge from current date
#deleteStatus = list(map(lambda x: dbutils.fs.rm(x,recurse=True), asOfDateFolderList))

print('Deleted below asofdate folders which are older than {} days from Today'.format(days_to_purge))
asOfDateFolderList#, deleteStatus
