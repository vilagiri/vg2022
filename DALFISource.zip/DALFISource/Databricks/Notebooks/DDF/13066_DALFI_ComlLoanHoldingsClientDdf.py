# Databricks notebook source
# MAGIC %run ../VersionedLibraries

# COMMAND ----------

# MAGIC %run ../common_functions

# COMMAND ----------

# MAGIC %run ../SharedFunctions

# COMMAND ----------

#Imports
from datetime import date, datetime, timedelta
from pyspark.sql.functions import *

# COMMAND ----------

# Get GDF Context
try:
  notebookName = '13066_DALFI_ComlLoanHoldingsClientDdf'
  gdfContext = GetGdfContext(notebookName)
  
  commonStructure = CommonStructure()
  commonStructure.AsOfDate = gdfContext.as_of_date
except:
  raise

# COMMAND ----------

# Layer 1 Data frames
try:
  asmt = gdfContext.get_df('coml_asmt_df') \
  .withColumn('AsOfDate',lit(datetime.strptime(gdfContext.as_of_date, '%Y%m%d').strftime("%Y-%m-%d")))
  posi = gdfContext.get_df('coml_posi_df')
  asrt = gdfContext.get_df('coml_asrt_df')
  prop = gdfContext.get_df('coml_prop_df')
  mnpp = gdfContext.get_df('coml_mnpp_df').withColumnRenamed("PortfolioCode","InvestmentsPortfolioCode")
  
  coml_asrt_df = gdfContext.get_df('coml_asrt_df').filter("RaterCode == 'MET' and  RatingTypeCode == 'MIMMortgage' and TermTypeCode == 'LT'  and RatingScopeCode == 'GSR' ") 
  
except:
  raise

# COMMAND ----------

# Join Layer 1 data frames
mnpp_posi_df = mnpp.join(posi,"InvestmentsPortfolioCode")
mnpp_posi_asmt_df = mnpp_posi_df.join(asmt,"MetLifeAssetID")
mnpp_posi_asmt_asrt_df = mnpp_posi_asmt_df.join(coml_asrt_df,"MetLifeAssetID")

# COMMAND ----------

#Direct Mapping
baseDf = mnpp_posi_asmt_asrt_df.select(
  'AsOfDate',
  'MetLifePartyID',
  'MetLifePartyName',
  'MetLifeAssetID',
  'InvestmentsPortfolioCode',
  'LoanClosedDate',
  'OutstandingPrincipalBalanceAmt',
  'PrincipalBalanceUSD',
  'MaturityDate',
  'RaterCode',
  'MetLifeRatingLoanToValueRatio',
  'BaseYearDebtServiceCoverageRatio',
  'LoanStatusCode',
  'REIManagedInd'
).dropDuplicates()


# COMMAND ----------

# PVP: Scope for Optimization: ReferernceFunctions call is materializing CDRF every time the function is called. We need to check the feasibility of materializing CDRF in the parent notebook and passing it as input parameter to the ReferenceFunctions functions.

loanPaymentTypeReference = ReferenceFunctions.GetCodeReferenceLookupDetails(commonStructure, 'LoanPaymentTypeReference')
ACLIPropertyTypeReference = ReferenceFunctions.GetCodeReferenceLookupDetails(commonStructure, 'ACLIPropertyTypeReference')
MSAReference =  ReferenceFunctions.GetCodeReferenceLookupDetails(commonStructure, 'MSAReference')

# COMMAND ----------

assetPropertyRelDf = GetExplodedDf2(asmt, ['MetLifeAssetID'], 'AssetPropertyRelations').dropDuplicates()
AssetPropDf1 = assetPropertyRelDf.join(prop,['MetLifePropertyID']).dropDuplicates()

AssetPropDf = AssetPropDf1.select('MetLifeAssetID','PropertyName').dropDuplicates()
ACLIDf = AssetPropDf1.join(ACLIPropertyTypeReference,'ACLIPropertyTypeCode').select('MetLifeAssetID','ACLIPropertyTypeDesc').dropDuplicates()
MSADf = AssetPropDf1.join(MSAReference,'MSACode').select('MetLifeAssetID','MSADesc').dropDuplicates()

# COMMAND ----------

loanPaymentDf = asmt.join(loanPaymentTypeReference,'LoanPaymentTypeCode').select('MetLifeAssetID','LoanPaymentTypeDesc').dropDuplicates()

# COMMAND ----------

loanIdDf = GetExplodedDf2(asmt, ['MetLifeAssetID', 'Identifier'], 'Identifier') \
.filter('Type=="OriginationSystemAssetID"') \
.withColumnRenamed('Value', 'LoanNumber') \
.select('MetLifeAssetID','LoanNumber').dropDuplicates()


# COMMAND ----------

intSchDf = GetEffectiveInterestSchedule (asmt) \
.select(
  col('MetLifeAssetID'),
  col('IntSched_InterestReferencedIndexID').alias('InterestReferencedIndexID'),
  col('IntSched_MetLifeInterestTypeCode').alias('MetLifeInterestTypeCode')
)

# COMMAND ----------

intRRSchDf = GetEffectiveInterestRateResetSchedule( asmt ) \
.select(
  col('IrrSchedule_MetLifeAssetID').alias('MetLifeAssetID'),
  col('InterestRate')
)

# COMMAND ----------

finalDf = baseDf.join( loanPaymentDf, 'MetLifeAssetID', 'left') \
.join( AssetPropDf, 'MetLifeAssetID', 'left') \
.join( ACLIDf, 'MetLifeAssetID', 'left') \
.join( MSADf, 'MetLifeAssetID', 'left') \
.join( loanIdDf, 'MetLifeAssetID', 'left') \
.join( intSchDf, 'MetLifeAssetID', 'left') \
.join( intRRSchDf, 'MetLifeAssetID', 'left').dropDuplicates()

# COMMAND ----------

try:
  gdfContext.dfname = '13066_DALFI_ComlLoanHoldingsClientDdf'
  gdfContext.store_curated_df(finalDf)
except Exception as e:
  raise
