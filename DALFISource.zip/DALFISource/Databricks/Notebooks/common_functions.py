# Databricks notebook source
'''
  CHANGELOG - common_functions:
    2020-10-29 DF: (No Work-Item ID) Added 2 functions to assist in SIT Test notebooks - AssetEquality() and WriteDfAsJsonToGrid()
    2020-11-20 DF: (Bug 336986) Fixed get_last_day_of_quarter - Now gets first_day_of_quarter for given date (as before) but then adds 3 months and then subtracts 1 day
    2020-11-25 DF: (No Work Item) Test VSCode-Databricks Extension Integration
'''

# COMMAND ----------

#Imports
import azure.cosmos.cosmos_client as cosmos_client
import bisect, calendar, datetime, dateutil.relativedelta, hashlib, json, types, unittest, uuid
from collections import namedtuple # 20200918 DF - DeserializeJson uses this, needs to be imported here
from dateutil.relativedelta import relativedelta
from dff.dfnotebook import DFNotebook, GDFContext
from pyspark.sql import functions as F
from pyspark.sql.types import *
from applicationinsights import TelemetryClient

# COMMAND ----------

class CommonStructure(object):
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

# COMMAND ----------

#Constants
CONST_DOS_DATABRICKS_SECRET_SCOPE = "grdo-databricks-kv-ss"
CONST_EXCEPTION_MUST_RUN_FROM_JOB_OR_OTHER_NOTEBOOK = 'This notebook must be called from a job or another notebook via dbutils.notebook.run().\n'
CONST_MOUNT_POINT = '/mnt/data/inv'

as_of_date_format = '%Y%m%d'
int_date_format = "%Y%m%d"
standard_date_format = "%Y-%m-%d"
sql_standard_date_format = "yyyy-MM-dd"

# COMMAND ----------

# General Functions

# Generic unittest assertEqual function that takes in an expected DF, actual DF, and a list of fields to compare
def AssertEquality(expectedDf, actualDf, fieldList):
  tc = unittest.TestCase()
  tc.maxDiff = None
  tc.assertEqual(expectedDf.select(*fieldList).collect(), actualDf.select(*fieldList).collect())

  
# DeserializeJson:  Deserializes a JSON string into an object tree
def DeserializeJson(jsonData):
  return json.loads(jsonData, object_hook=lambda d: namedtuple('Json', d.keys())(*d.values()))

  
#  GetExplodedDf:  Gets a dataframe with  specified fields from a nested (child) object of an existing dataframe
def GetExplodedDf(df, fields, childDfName):
  newDf = df.select(*fields)
  try:
    newDf = newDf.withColumn(childDfName, F.explode(childDfName))
  except Exception as e:
    newDf = newDf.withColumn(childDfName, F.explode(F.array(childDfName)))
  field_names = newDf.select(childDfName).schema.fields[0].dataType.fieldNames() 
  field_names = [i for i in field_names if i not in fields]
  selectString = '{}.%s'.format(childDfName)
  select_clause = [selectString % r for r in field_names]
  select_clause.insert(0,'*')
  return newDf.select(select_clause).drop(childDfName)


def GetExplodedDf2(df, nonChildFieldsList, childDfName):
  newDf = df.select(*nonChildFieldsList, childDfName)
  newDf1 = newDf.alias('Df1')
  explodedChildDfName = 'ExplodedDf_' + childDfName
  childDfFields = explodedChildDfName + '.*'
  try:
    newDf2 = newDf1.select('Df1.*', F.explode(childDfName).alias(explodedChildDfName)).alias('Df2').drop(childDfName)
  except Exception as e:
    print(e)
    newDf2 = newDf1.select('Df1.*', F.explode(F.array(col(childDfName))).alias(explodedChildDfName)).alias('Df2').drop(childDfName)

  return newDf2.select('Df2.*', childDfFields).drop(explodedChildDfName).alias(childDfName)

# Writes a dataframe as JSON to a specified GRID path
def WriteDfAsJsonToGrid(df, gridPath):
  dbfsFile = '/dbfs%s' % (gridPath)
  json_ = df.toJSON().map(lambda j: json.loads(j)).collect()
  dbutils.fs.rm(dbfsFile)
  with open(dbfsFile, 'w') as f:
    f.write(json.dumps(json_))
    f.close()

# COMMAND ----------

# GDF Helper Functions


# Get Environment context
def GetEnvironment():
    return {
      'dbutils': dbutils,
      'spark': spark, 
      'sparkContext': sc, 
      'sqlContext': sqlContext, 
      'mount': CONST_MOUNT_POINT, 
      'sql': sql
    }

  
# GetGdfContext:   Get GDF notebook context with env variables; If As-Of Date, Region, and Period are not supplied then assume GDF context already exists with variables already set
def GetGdfContext(gdfRegistryName, asOfDate='', period='', region='', get_adjusted_df='',dataClass =''):
  print("preparing context")
  
  try:
    
    env = GetEnvironment()
  
    gdfContext = GDFContext(gdfRegistryName, env, as_of_date=asOfDate)
    if (len(asOfDate) > 0):
      gdfContext.as_of_date = asOfDate
      gdfContext.period = period
      gdfContext.region = region 
      gdfContext.class_ = dataClass
      
    if (len(get_adjusted_df) > 0):
      gdfContext.get_adjusted_df = get_adjusted_df
      
      
    exceptionMessage = ''
    if (len(gdfContext.as_of_date) == 0):
      exceptionMessage = exceptionMessage + 'GRID As-Of Date (as_of_date) was not set by a caller.\n'
    if (len(gdfContext.period) == 0):
      exceptionMessage = exceptionMessage + 'GRID Period (period) was not set by a caller.\n'
    if (len(gdfContext.region) == 0):
      exceptionMessage = exceptionMessage + 'GRID Region (region) was not set by a caller.\n'
    if (len(exceptionMessage) > 0):
      raise Exception(exceptionMessage + 'This notebook must be instantiated in another notebook\'s context, be called from a job or dbutils.')
    
    return gdfContext
  except Exception as e:
    print(str(e))
    

#Function for Assembler notebook that returns the dataframe for the passed in date if it exists. Else returns the latest dataframe from  previous dates
def GetLatestDf(gdfContext, dfName):
  try:
    df=gdfContext.get_df(dfName)
    return df
  except: 
    asOfDate = gdfContext.get_previous_latest_as_of_date(dfName)
    latestDf = gdfContext.get_df(dfName,as_of_date = asOfDate)
    return latestDf



# COMMAND ----------

# Date functions

def get_quarter(date):
    return (date.month - 1) // 3 + 1

def get_first_day_of_quarter(dateToCheck):
    qBegins = [datetime.date(dateToCheck.year, month, 1) for month in (1,4,7,10)]
    idx = bisect.bisect(qBegins, dateToCheck)
    return qBegins[idx-1]
  
def get_last_day_of_quarter(dateToCheck):
    firstDayOfQuarter = get_first_day_of_quarter(dateToCheck)
    #monthDays = calendar.monthrange(firstDayOfQuarter.year, firstDayOfQuarter.month)[1]
    nextQuarter = firstDayOfQuarter + relativedelta(months=3)
    lastDayOfQuarter = nextQuarter + relativedelta(days=-1)
    return lastDayOfQuarter
  
def _getPriorPeriodDf(priorPeriodDate, dfName, region):
  currentAsOfDate = gdfContext.as_of_date
  currentRegion = region
  try:  
    gdfContext.region = region
    gdfContext.as_of_date = priorPeriodDate.strftime(as_of_date_format)
    gdfContext.as_of_date = gdfContext.get_previous_latest_as_of_date(dfName)
    print('_getPriorPeriodDf.gdfContext.as_of_date', gdfContext.as_of_date, ', region = ', gdfContext.region)
    returnDf = gdfContext.get_df(dfName)
    gdfContext.as_of_date = currentAsOfDate
    gdfContext.region = currentRegion
    return returnDf
  except:
    gdfContext.as_of_date = currentAsOfDate
    gdfContext.region = currentRegion
    raise
    
# GetPriorBusinessDateFromCalendar:  Get the most recent business date N months prior to the given date; hoilidayDatesDf should only contain list of dates where no trail was run
def GetPriorBusinessDateFromCalendar(currentAsOfDate, deltaMonths, deltaDays, calendarDatesDf, noWeekendBusiness):
  priorBusinessDate = currentAsOfDate - dateutil.relativedelta.relativedelta(months=deltaMonths, days=deltaDays)
  isWeekendOrHoliday = ((priorBusinessDate.weekday() in [5,6]) & (noWeekendBusiness))
  isWeekendOrHoliday = isWeekendOrHoliday | (len(calendarDatesDf.select(calendarDatesDf.CalendarDate == priorBusinessDate.strftime(standard_date_format)).take(1)) > 0)
  while (isWeekendOrHoliday):
    priorBusinessDate = priorBusinessDate - dateutil.relativedelta.relativedelta(days=+1)
    isWeekendOrHoliday = ((priorBusinessDate.weekday() in [5,6]) & (noWeekendBusiness))
    isWeekendOrHoliday = isWeekendOrHoliday | (len(calendarDatesDf.filter(calendarDatesDf.CalendarDate == priorBusinessDate.strftime(standard_date_format)).take(1)) > 0)
    
  return priorBusinessDate


# GetPriorBusinessDateWithData(currentAsOfDate, deltaMonths, deltaDays)
def GetPriorBusinessDateWithData(currentAsOfDate, deltaMonths, deltaDays, gdfContext, dfNameToCheck):
  priorBusinessDate = currentAsOfDate - dateutil.relativedelta.relativedelta(months=deltaMonths, days=deltaDays)
  initialPriorBusinessDate = priorBusinessDate
  priorBusinessDateDf = gdfContext.get_df(dfNameToCheck, as_of_date=priorBusinessDate.strftime('%Y%m%d'), silent=True)
  maxTries = 10
  retries = 0
  while ((priorBusinessDateDf.count() == 0) & (retries < maxTries)):
    priorBusinessDate = priorBusinessDate - dateutil.relativedelta.relativedelta(days=1)
    priorBusinessDateDf = gdfContext.get_df(dfNameToCheck, as_of_date=priorBusinessDate.strftime('%Y%m%d'), silent=True)
    retries = retries + 1
    
  if (priorBusinessDateDf.count() == 0):
    raise Exception("Unable to find data for Business Date {0} - checked through {1} days.".format(initialPriorBusinessDate.strftime('%Y%m%d'), str(maxTries)))
  
  return priorBusinessDate


  
def GetPriorQuarterDf(dfName, region):
  currentAsOfDate = datetime.datetime.strptime(gdfContext.as_of_date, as_of_date_format)
  priorPeriodDate = datetime.datetime.combine(get_first_day_of_quarter(currentAsOfDate.date()), datetime.datetime.min.time())
  print('GetPriorQuarterDf.priorPeriodDate ==', priorPeriodDate)
  return _getPriorPeriodDf(priorPeriodDate, dfName, region)


def GetPriorYearDf(dfName, region):
  currentAsOfDate = datetime.datetime.strptime(gdfContext.as_of_date, as_of_date_format)
  priorPeriodDate = datetime.datetime.strptime(str(currentAsOfDate.year) + '0101', as_of_date_format)
  print('GetPriorYearDf.priorPeriodDate ==', priorPeriodDate)
  return _getPriorPeriodDf(priorPeriodDate, dfName, region)


# COMMAND ----------

# Commitments Functions

def GetCommitmentDataSet(as_of_date, period, region,  get_adjusted_df="N"):
  try:
    # reading existing masterset
    import pyspark.sql.functions as F
    from pyspark.sql.functions import col,lit, desc, asc
    import datetime
    import dff.dfadjustments
    env = GetEnvironment()
    
    gdfContext_without_adj = GDFContext("MasterCmmtDataSet", env, get_adjusted_df="N")
    gdfContext_without_adj.environment.spark().catalog.refreshTable("Commitment") if "commitment" in list(map(lambda x: x.name , spark.catalog.listTables())) else None
    existingCommitment = gdfContext_without_adj.environment.spark().table("Commitment")

    # reading partial asOfDate commitment dataset 
    gdfContext_without_adj.as_of_date = as_of_date
    gdfContext_without_adj.period = period
    gdfContext_without_adj.region = region
    cmmt_df_asOfDate = gdfContext_without_adj.get_df("coml_cmmt_df")
    cmmt_df_with_audit = cmmt_df_asOfDate.withColumn("updated_on", lit(datetime.datetime.now()))

    # combining partial dataset with existing commitment datatable 
    combined_Df = existingCommitment.union(cmmt_df_with_audit.select(existingCommitment.columns))
    latest_cmmt = combined_Df.groupBy(["MetLifeAssetID","InvestmentsPortfolioCode"]).agg(F.max(F.col("updated_on")).alias("updated_on"))
    final_cmmt_df = combined_Df.join(latest_cmmt, ["MetLifeAssetID","InvestmentsPortfolioCode","updated_on"])
    
    # writing into temp table 
    gdfContext_without_adj.environment.spark().sql('DROP TABLE IF EXISTS temp_Commitment')
    final_cmmt_df.write.format("parquet").mode("overwrite").saveAsTable("temp_Commitment")
    gdfContext_without_adj.environment.spark().table("temp_Commitment").write.format("parquet").mode("overwrite").saveAsTable("Commitment")
    gdfContext_without_adj.environment.spark().sql('DROP TABLE IF EXISTS temp_Commitment')
    
    # reading data again to make sure we are not going to face any issues for further 
    gdfContext_without_adj.environment.spark().catalog.refreshTable("Commitment") if "commitment" in list(map(lambda x: x.name , spark.catalog.listTables())) else None
    mast_commitment_df = gdfContext_without_adj.environment.spark().table("Commitment").drop("updated_on")
    # applying adjustments on top of master set of commitments
    if get_adjusted_df == "Y":
      cmmt_ovrr_df = gdfContext_without_adj.get_df("coml_cmmt-ovrr_df", use_prev_as_of_dates=True, silent=True)
      try:
        scheduledKeys = gdfContext_without_adj.registry.get_effective_scheduled_keys("coml_cmmt_df")
        override_results = gdfContext_without_adj.apply_adjustments(mast_commitment_df, cmmt_ovrr_df,scheduledKeys)
      except:
        raise
      return override_results
    else:
      return mast_commitment_df
  except:
    raise

# COMMAND ----------

# DOS Functions

#Retrieving secrets stored in keyvault using scopes
cosmosKey = dbutils.secrets.get(scope = CONST_DOS_DATABRICKS_SECRET_SCOPE, key = "Cosmos-DB-Key")
cosmosEndpoint = dbutils.secrets.get(scope = CONST_DOS_DATABRICKS_SECRET_SCOPE, key = "Cosmos-DB-Endpoint")
cosmosDBName = dbutils.secrets.get(scope = CONST_DOS_DATABRICKS_SECRET_SCOPE, key = "Cosmos-DB-DBName")

def DeleteFromDOS(collName,partitionKey):
  try:
    client = cosmos_client.CosmosClient(url_connection=cosmosEndpoint, auth={'masterKey': cosmosKey})
    database_link = 'dbs/' + cosmosDBName
    database = client.ReadDatabase(database_link)
    col_link = GetContainerLink("DP_DOS_DB",collName)
    query = {
                "query": "SELECT * FROM r"
            }
    options = { 'enableCrossPartitionQuery': True }
    results = list(client.QueryItems(col_link, query,options))
    for doc in results:
      options = { 'partitionKey': doc.get(partitionKey) or {} } # Bug 66321:  Use "or {}" to default to empty JSON when partitionKey value is NULL (https://github.com/Azure/azure-cosmosdb-node/issues/222)
      client.DeleteItem( GetDocumentLink(cosmosDBName,collName, doc), options)
  except:
    raise

    
def GetContainerLink(database_id, collection_id):
    return GetDatabaseLink(database_id) +  "/" + "colls" + "/" +  collection_id

  
def GetDatabaseLink(database_id):
    return "dbs" + "/" + database_id  

  
def GetDocumentLink(database, document_collection, document, is_name_based=True):
    if is_name_based:
        return GetContainerLink(database, document_collection) + '/docs/' + document['id']
    else:
        return document['_self']

      
# WriteToDos:  Writes a dataframe content out to DOS
# POC:  jL3dAhsuv1NSe7BKhdwWqasviudXor7AZrff3NzajZ2ST0QsvK2Db02U7Pv8zz4FgGtNbbdF3KcKfAV9WzGvkA==
# DEV:  qKRUjYVyg7JRG1SPSBbMB9grDwBU24ZBFFnBb2fw1Hbi1QOMZMJRBeXOZx1GbE73c0Hn1wpdPMRXSnxCMBOhWQ==
def WriteToDos(containerName, df):
  Dos = DeserializeJson('''{
      "Config": {
        "Collection": "''' + containerName + '''"
        , "Database": "'''+cosmosDBName+'''"
        , "Endpoint": "'''+cosmosEndpoint+'''"
        , "MasterKey": "'''+ cosmosKey + '''"
        , "Upsert": "true"
      }
    }''')
  writeConfig = {
    "Endpoint": Dos.Config.Endpoint
    , "Masterkey": Dos.Config.MasterKey
    , "Database": Dos.Config.Database
    , "Collection":containerName 
    , "Upsert": Dos.Config.Upsert
    #, "WritingBatchSize": "50" #Test for RU issue for SecPos
  }
  df.write.format("com.microsoft.azure.cosmosdb.spark").mode("overwrite").options(**writeConfig).save()


# COMMAND ----------

# UDFs

# UdfGetQuarter:  Returns the quarter pertaining to a given date
def UdfGetQuarter(DateVal):
  asOfDateMonth = DateVal.month
  return (asOfDateMonth-1)//3


# UdfGetYear:  Returns the year portion of a given date
def UdfGetYear(date):
  return date.year


# HashSha:  Provides a hash of a given set of keys
def UdfHashSha(combinedKeys):
  h = hashlib.new('SHA')
  h.update(combinedKeys.encode('utf-8'))
  return h.hexdigest()  


dateUDF = udf(lambda x: UdfGetQuarter(x), IntegerType())
udfHashSha = udf(lambda z: UdfHashSha(z), StringType())
uuidUdf = udf(lambda : str(uuid.uuid4()),StringType())
yearUDF = udf(lambda x: UdfGetYear(x), IntegerType())


# COMMAND ----------

def WriteToTelemetry(logMessage):
  try:
    tc = TelemetryClient(dbutils.secrets.get(scope = CONST_DOS_DATABRICKS_SECRET_SCOPE, key = "AppInsights-InstrumentationKey"))
    tc.track_trace(logMessage)
    tc.flush()
  except:
    raise