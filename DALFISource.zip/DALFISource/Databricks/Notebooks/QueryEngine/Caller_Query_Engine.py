# Databricks notebook source
# MAGIC %md
# MAGIC # Query Engine Invoker
# MAGIC 
# MAGIC  

# COMMAND ----------

# MAGIC %run ../VersionedLibraries

# COMMAND ----------

# MAGIC %run ../common_functions

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. load the query engine code

# COMMAND ----------

# MAGIC %run ./Query_Engine

# COMMAND ----------

queryDefinition = dbutils.widgets.get('queryDefinition')
payLoad = dbutils.widgets.get('payLoad')
queryInstanceID = dbutils.widgets.get('queryInstanceID')

# COMMAND ----------

print(queryDefinition)
print(payLoad)
print(queryInstanceID)

# COMMAND ----------

#queryDefinition = '{"name" : "param_test","description" : "","parameters" : [{ "parameter" : "PARTY", "type" : "string*"},{ "parameter" : "OUTFILE", "type" : "string"},{ "parameter" : "MANDATE", "type" : "string"}],"sources":  [{"df" : "coml_mnpp_df as mnppDf"},{"df" : "mast_mnpr_df as mnprDf"}],"filters": [{ "field": "mnppDf.MetLifePartyID", "values": "<PARTY>"},{ "field": "mnppDf.InvestorMandateID", "values": "<MANDATE>"}],"joins":[{"leftDf": "mnppDf", "rightDf": "mnprDf", "join" : "(leftDf.MetLifePartyID == rightDf.MetLifePartyID) & (leftDf.InvestorMandateID == rightDf.InvestorMandateID)", "how":"inner"}],"outputs" : [{"filename": "<OUTFILE>.csv","folder" : "/mnt/data/Training/prototype/export/output","format" : "csv","fields": [{ "target":"PartyID", "field":"mnppDf.MetLifePartyID"},{ "target":"MandateID", "field":"mnppDf.InvestorMandateID"}]}]}'

#payLoad = '{"query": "param_test","as_of_date":"20200817","region":"glob","eaicode": "12096","period":"d","parameters" : [{ "parameter":"PARTY", "value": ["M000D9", "M002L3"]}, {"parameter": "OUTFILE", "value": "Filter_test1"}, {"parameter": "MANDATE", "value": "a0Y1A00000dTmHKUA0"}]}'

#queryInstanceID = '0001'

# COMMAND ----------

# wrapper function to create gdf context and invoke core query engine functionality
def run_api_query(queryDef, payload,queryInstanceID):
  test = ast.literal_eval(payload)
  try:
      gdf_context = GetGdfContext("Caller_QueryEngine", asOfDate=test['as_of_date'], period=test['period'], region=test['region'], get_adjusted_df='Y')
  except:
    raise
    print("**********************************************************************************************************************************************")
  finalPath = GDA.execute_queries(queryDef, gdf_context, payload, queryInstanceID, debug=True)
  return finalPath
  

# COMMAND ----------

import traceback

path=""
errorMessage =""
status=""
try:
  path = run_api_query(queryDefinition, payLoad, queryInstanceID)
  status = "Success"
except Exception as e  :
  #errorMessage = str(e)
  #errorMessage = traceback.format_exc().strip()
  # https://docs.python.org/3/library/traceback.html#traceback.format_exception_only
  # As per python documentation, the message indicating which exception occurred is always the last string in the list.
  errorMessage = traceback.format_exception_only(type(e), e)[-1].strip().replace('"','\\"')
  status = "Failure"
  print("")
  print('***** Traceback Exception Information *****')
  traceback.print_exc()

# COMMAND ----------

exit_resp='{"ReturnValue": {"status": "' + str(status) +'","path": "' + str(path) + '","errorMessage": "' + str(errorMessage) + '"}}'
dbutils.notebook.exit(exit_resp)