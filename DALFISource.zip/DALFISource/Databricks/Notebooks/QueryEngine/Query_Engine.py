# Databricks notebook source
from pygments.filters import FILTERS
#from pyspark.sql.functions import lit
#from pyspark.sql import functions as F
#from pyspark.sql.functions import col, lit, udf
#from pyspark.sql.types import FloatType, StringType, DecimalType
from pyspark.sql import *
from pyspark.sql.functions import * #array, col, collect_list, concat, explode, lit, struct
from pyspark.sql.types import *

import json
import re
from pprint import pprint
import copy
import ast
import datetime
import os

# COMMAND ----------

#  Constants
SOURCES = 'sources'
FILTERS = 'filters'
JOINS = 'joins'
OUTPUTS = 'outputs'
FIELDS= 'fields'
FORMAT = 'format'
FILENAME = 'filename'
FOLDER = 'folder'
OUTPUT = 'fields'

# COMMAND ----------

class GDA:
  def __init__(self):
    pass

  @staticmethod
  def fallback_Df(gdfContext, dfName, _asOfDate, _region, _period):
    """
    This method trys to get the dataframe for given as of date, region and period. If the dataframe is not available, it will 
    return the data for the latest avaialble prior date.
    Creating a separate function as Commonfunctions.GetLatestDf() don't take in region and period as input parameters.
    """
    try:
      df=gdfContext.get_df(dfName, as_of_date = _asOfDate, region=_region, period=_period)
      return df
    except: 
      asOfDate = gdfContext.get_previous_latest_as_of_date(dfName, region=_region, period=_period)
      latestDf = gdfContext.get_df(dfName,as_of_date = asOfDate,  region=_region, period=_period)
      return latestDf

  @staticmethod
  def explode_df(df, childDfName):
    try:
      newDf = df.withColumn(childDfName, F.explode(childDfName))
    except Exception as e:
      newDf = df.withColumn(childDfName, F.explode(F.array(childDfName)))
    field_names = newDf.select(childDfName).schema.fields[0].dataType.fieldNames() 
    field_names = [i for i in field_names]
    selectString = '{}.%s'.format(childDfName)
    select_clause = [selectString % r for r in field_names]
    select_clause.insert(0,'*')
    return newDf.select(select_clause).drop(childDfName)

  @staticmethod
  def build_df_map(pay_load, query_instance, gdf_context):
    """ this method parses the list of source dataframes and returns a dictionary that maps each dataframe alias to its respective 
     GDF dataframe object in each entry of the source_df_list, the dataframes with their aliases are expressed as a string of 
     the form '<df> as <alias>'
    """
    payload_values = ast.literal_eval(pay_load)
    source_df_list = query_instance[SOURCES]       # list of strings for the dataframes to use as inputs
    
    as_pat = re.compile(r'([.a-zA-Z0-9_-]+) as ([a-zA-Z0-9_-]+)')  
    df_map = {}      
    for din in source_df_list:
      m = as_pat.match(din['df'])
      if m:
        dfname = m.group(1)
        dfalias = m.group(2)

        #check if as_of_date info is available in the query definition source details. If not, takes the payload base as_of_date.
        if din.get('as_of_date',None):
          _asOfDate = din['as_of_date']
        else:
          _asOfDate = gdf_context.as_of_date    
        #check if region info is available in the query definition source details. If not, takes the payload base region.
        if din.get('region',None):
          _region = din['region']
        else:
          _region = gdf_context.region
        #check if period info is available in the query definition source details. If not, takes the payload base period.  
        if din.get('period',None):
          _period = din['period']
        else:
          _period = gdf_context.period
        #check if fallback to previous asofdate flag is set for source definition then use that value
        #else check if fallback to previous asofdate flag is set in Query Definition then use that value
        if din.get('fallback_to_previous_as_of_date',None):
          _fallback = din['fallback_to_previous_as_of_date']
        elif ('fallback_to_previous_as_of_date' in query_instance):
          _fallback = query_instance['fallback_to_previous_as_of_date']
        else:
          _fallback = False

        df_parts = dfname.split('.')
        dfname = df_parts[0]

        if not _fallback:
          df = gdf_context.get_df(dfname, as_of_date = _asOfDate, region=_region, period=_period).df
        else:
          df = GDA.fallback_Df(gdf_context, dfname, _asOfDate, _region, _period).df


        if len(df_parts) > 1:
          array_field = df_parts[-1]
          for part in df_parts[1:-1]:
            df = GDA.explode_df(df, part)
          df_map[dfalias] = GDA.explode_df(df, array_field)
        else:
          df_map[dfalias] = df 
      else:
        raise Exception('parsing error on query source: %s' % din)
    return df_map
  
  @staticmethod
  def split_alias_field(alias_dot_field):
    return alias_dot_field.split('.')

  @staticmethod
  def extract_joins(query_joins, df_map):
    """ extract_joins() will parse the list of query_joins structures and returns the final joined dataframe after 
     applying the joins described in the meta-data
    """
    #Initializing the dataframe to be returned
    final_df = None

    #If its a single dataframe query definition, it is assinged to the df to be retuned.
    if len(df_map) == 1:
      key = list(df_map)[0]
      final_df = df_map[key]

    else:
      for j in query_joins:
        # Identify Left and right dataframes to be used in the Join.
        leftDf = df_map[j['leftDf']]
        rightDf = df_map[j['rightDf']]

        # If its the first join
        if not final_df:
          final_df = leftDf

        joinCondition = str(j['join'])      
        final_df = final_df.join(rightDf, eval(joinCondition), how=j['how'])

    return final_df

  @staticmethod
  def apply_filters(query_filters, df, df_map):
    """  apply_filters() will apply the filters defined in the list of query_filters structures to df and return the resulting filtered df
    """
    filtered_df = df

    for f in query_filters:
      # Apply filter only if values are provided for that filter
      if "values" in f and f['values']: 
        (dfalias, field) = GDA.split_alias_field(f['field'])
        sparkdf = df_map[dfalias]
        colm = sparkdf[field]
        # Converting both column value and filter value to upper case to avoide case mismatch of values
        # TBD: Applying upper() to column will affect results if df column is not string type. Need to revist when Query have INT filters
        filter_values = f["values"]
        if isinstance(filter_values, list):
          filter_values = list(map(lambda x: x.upper() if isinstance(x, str) else x, filter_values))
        else:
          filter_values = filter_values.upper() if isinstance(filter_values, str) else filter_values
          
        #filtered_colm = colm.isin(f['values'])
        filtered_colm = upper(colm).isin(filter_values)  
        print("Filter: ",filtered_colm)
        filtered_df = filtered_df.filter(filtered_colm)
      
    return filtered_df

  @staticmethod
  def apply_format(col, fmt):
    """ apply_format() will take a column and a string format, and will return a function that casts the column to the specified format
    """
    # "format":"decimal(18,2)"
    # TODO: fix this not to hard code the column to Decimal(18,2)
    print("apply_format(%s, %s)"%(col, fmt))

    pat = re.compile(r'([a-zA-Z]+)\(([0-9,]+)\)')
    m = pat.match(fmt)
    if m:
      typ = m.group(1)
      prec_scale= m.group(2)

      if typ == 'Decimal':
        return col.cast(DecimalType(18,2))
    return col

  @staticmethod
  def apply_projection(projection, df, df_map):
    """ apply_projection() will parse the list of projection structures that defines the fields to include in an output dataframe, and it 
    will select those fields from the source df and project it to an output dataframe, applying any functions, aliases & formats as it does so
    projection is a list of projection objects, each of which may have:
    'target' - required
    either 'field' or 'default' are requird, but not both
    if both are present, then 'default' is the value to use when 'field' is Null
    'calculation' - optional function that is applied to field or default and result is used for output target
    """
    projected_cols = []
    for o in projection:
      output_alias = o['target']
      print("O: ",o)
      if o.get('field',None):
        (df_alias, df_field) = GDA.split_alias_field(o['field'])
        sparkdf = df_map[df_alias]
        colm = sparkdf[df_field]
        colm_alias = colm.alias(output_alias)

        if  o.get('default',None):
          # If null, select the default valued column, else select the original column
          colval = when(colm.isNull(),lit(o['default'])).otherwise(colm).alias(output_alias)
        else:
          colval = colm_alias
      # otherwise 'field' is not present and 'default' is
      elif 'default' in o: # changing from get() to in as get() is not fetching when value is None or blank ("")
        colval = lit(o['default']).alias(output_alias)
      elif o.get('calculation',None):
        # if there is a calculation specified, apply it to the column value
        calc_struct = o.get('calculation')
        exp = calc_struct['expression']

        # Convert fields mentioned as <dataFrameName>.<FieldName> in the expression to df_map[<dataFrameName>][<FieldName>]. 
        # This is to establish the binding between the field to the dictionary storing its baseDf.
        for f in  calc_struct['fields']:
          (df_alias, df_field) = GDA.split_alias_field(f)
          dfmap_cols = "df_map['"+df_alias+"']['"+df_field+"']"
          exp = exp.replace(f,dfmap_cols)

        colval = eval(str(exp)).alias(output_alias)
      else:
        raise Exception('error in output - either field or default or calculation must be present')
      if o.get('format', None):
        fmt = o['format']
        colval = GDA.apply_format(colval, fmt)
      projected_cols.append(colval)     

    return df.select(projected_cols)
  
  @staticmethod
  def execute(pay_load, query_instance, gdf_context, debug=False):
    """ returns a list of output dataframes that result from executing the query defined in query_instance
    """    
    filters = query_instance[FILTERS]      # list of objects with "field" and "values"
    joins = query_instance[JOINS]          # list of objects with "join" and "how"
    output_defs = query_instance[OUTPUTS]  # list of objects with output projections  

    df_map = GDA.build_df_map(pay_load, query_instance, gdf_context)
    joined_df = GDA.extract_joins(joins, df_map)
    filtered_df = GDA.apply_filters(filters, joined_df, df_map)
    
    df_list = []
    for output_def in output_defs:
      fields = output_def[FIELDS] 
      projected_df = GDA.apply_projection(fields, filtered_df, df_map)
      df_list.append(projected_df)
    return df_list

  @staticmethod
  def get_files(dir_path):
    dir_files = dbutils.fs.ls(dir_path)
    json_files = []    
    for file in dir_files: # Considering only root directory
        if file.path.endswith('.json'):
            json_files.append(os.path.join('/dbfs', file.path[6:]))
    return json_files
  
  @staticmethod
  def export_output_json(df,payload,queryInstanceID, debug=False):
    payload_dict = ast.literal_eval(payload)
    eaiCode = payload_dict['eaicode']
    asofDate = payload_dict['as_of_date']
    queryName = payload_dict['query']
    frequency = payload_dict['period']
    recordCount = df.count()
    run_datetime = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    
    path = '/mnt/data/inv/ddz/'+eaiCode+'/'+queryName+'/'+asofDate
    multipart_path = path+'/multipart_'+run_datetime 
    file_name  = queryName+'_'+queryInstanceID+'_'+asofDate+'_'+eaiCode+'_'+frequency+'_'+run_datetime+'.json'
    final_filepath = path + '/' + file_name
    
    #dbutils.fs.rm(path, recurse=True)
    df.write.format('json').mode("overwrite").option("lineSep", ",").save('dbfs:%s' % (multipart_path))
    
    json_files = GDA.get_files(multipart_path)
    
    final_filepath = '/dbfs%s' % (final_filepath)
    #dbutils.fs.rm(final_filepath, False)
    
    header = '{"Header":{"QueryName": "' + str(queryName) + '", "EAICode": "' + str(eaiCode) + '", "RecordCount": "' + str(recordCount) + '", "AsOfDate": "' + str(asofDate) + '", "QueryInstanceID": "' + str(queryInstanceID) + '"},"Items": ['
    
    footer = ']}'
    
    with open(final_filepath, 'a') as mergefile:
      mergefile.write(header) # write header
      for file in json_files[:-1]: # append all files except the last file
          with open(file, 'r') as f:
            mergefile.write(f.read())
        
      with open(json_files[-1]) as lastfile: # for the last file, remove the comma at the end of file
          mergefile.write(lastfile.read()[0:-1])
      mergefile.write(footer) # append footer
    
    output_filePath = final_filepath.replace("/dbfs/mnt/","")
    return output_filePath
          
  
  @staticmethod
  def apply_parameter(queryDef, payload):
    """Query defintion parameter placeholders are replaced with actual paramter value coming from the payload
    """
    # convert to dictionary 
    query_dict = ast.literal_eval(queryDef)
    payload_dict = ast.literal_eval(payload)
    # retrieve parameter info from payload dictionary 
    parameter_dict = payload_dict['parameters']

    qDef = queryDef

    for param in query_dict['parameters']:
      q_pname = param['parameter']
      q_ptype = param['type']
      for payloadParam in parameter_dict:
        p_name = payloadParam['parameter']
        if q_pname == p_name:
          pval = payloadParam["value"]
          if q_ptype == "string":
            qDef = qDef.replace(str('<'+q_pname+'>'), pval)
          else:
            qDef = qDef.replace(str('"<'+q_pname+'>"'), str(pval))
            
    query_inst = ast.literal_eval(qDef)

    return query_inst

  @staticmethod
  def execute_queries(queryDef, context, payload, queryInstanceID, debug=False):
    """ applyies parameters to the query-definition and then executes the queries, ultimately storing the results as 
    temporary files as specified in the query definition
    """
    
    query_instance = GDA.apply_parameter(queryDef, payload)
    if debug:
      print("Fully qualified Query Instance: ")
      pprint(query_instance)

    df_list = GDA.execute(payload, query_instance, context, debug)    

    # output the dataframe into the ADLS location
    for output in df_list:
      filePath = GDA.export_output_json(output,payload,queryInstanceID,debug)
      
    return filePath
