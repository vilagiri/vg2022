
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanPriceDaily nvarchar(max) ='{
  "name": "COMLLoanPriceDaily",
  "description": "",
  "parameters": [],
  "sources": [
    {
      "df": "coml_asmt_df as asmt",
      "period": "d"
    },
    {
      "df": "coml_lprc_df as lprc",
      "period": "d"
    }
  ],
  "joins": [
    {
      "leftDf": "asmt",
      "rightDf": "lprc",
      "join": "leftDf.MetLifeAssetID == rightDf.MetLifeAssetID",
      "how": "inner"
    }
  ],
  "filters": [],
  "outputs": [
    {
      "fields": [
        {
          "field": "asmt.MetLifeAssetID",
          "target": "MetLifeAssetID"
        },
        {
          "field": "lprc.PriceDate",
          "target": "EffectiveDate"
        },
        {
          "format": "Decimal(18,2)",
          "field": "asmt.LoanToValueRatio",
          "target": "CurrentLoanToValueRatio"
        },
        {
          "field": "lprc.LoanPrice",
          "target": "BRSPrice"
        },
        {
          "default": "Evaluate",
          "target": "BRSPriceType"
        },
        {
          "field": "asmt.AmortizationStartDate",
          "target": "AmortizationStartDate"
        }
      ]
    }
  ]
}'

declare @PriceDailyApplicationId int,@PriceDailyCommApplicationId int,  @PriceDailyQueryDefinitionId int;

IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanPriceDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES		('COMLLoanPriceDaily','1.0',@COMLLoanPriceDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] set [QueryDefinitionSchema] =@COMLLoanPriceDaily 
WHERE [QueryDefinitionName]='COMLLoanPriceDaily'
END

SELECT @PriceDailyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @PriceDailyCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'
SELECT @PriceDailyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanPriceDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceDailyApplicationId AND [QueryDefinitionId] = @PriceDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceDailyApplicationId, @PriceDailyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceDailyCommApplicationId AND [QueryDefinitionId] = @PriceDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceDailyCommApplicationId, @PriceDailyQueryDefinitionId)
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH