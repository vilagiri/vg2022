
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_int nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "DAL_QueryEngine",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://eastus.azuredatabricks.net"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "1017-185132-dunk267"
      },
      {
        "name": "token",
        "value": "Int.grid.keyVault|Int-dbrick0004-Token"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "33793"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @INTNotebookQueryDefinitionId int

--COMLLoanHoldings
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldings' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanHoldingsDaily
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsDaily' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanCashFlow
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlow'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanCashFlowDaily
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlowDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanCommitmentsFull
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFull'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanHoldingsClient
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsClient'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanPrice
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPrice'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanPriceDaily
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END
--PortfolioMasterDaily
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='PortfolioMasterDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanHoldingsMonthly
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

--COMLLoanPriceMonthly
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END
--MASTPortfolioByProductTypeDaily
 SELECT @INTNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('INT',@INTNotebookQueryDefinitionId, @DAL_QueryEngine_int)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_int 
WHERE QueryDefinitionId=@INTNotebookQueryDefinitionId and EnvironmentName ='INT'
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH