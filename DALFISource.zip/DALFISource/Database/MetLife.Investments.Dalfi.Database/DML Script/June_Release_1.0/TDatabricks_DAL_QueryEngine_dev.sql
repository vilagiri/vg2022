
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_dev nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "GRID_DAL",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://eastus.azuredatabricks.net"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "0608-155640-alit27"
      },
      {
        "name": "token",
        "value": "Dev.grid.keyVault|Dev-Databricks-Token"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "20540"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @DEVNotebookQueryDefinitionId int

--COMLLoanHoldings
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldings' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsDaily' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCashFlow
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlow'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCashFlowDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlowDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCommitmentsFull
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFull'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsClient
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsClient'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanPrice
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPrice'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanPriceDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END


--PortfolioMasterDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='PortfolioMasterDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsMonthly
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanPriceMonthly
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END
--MASTPortfolioByProductTypeDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH