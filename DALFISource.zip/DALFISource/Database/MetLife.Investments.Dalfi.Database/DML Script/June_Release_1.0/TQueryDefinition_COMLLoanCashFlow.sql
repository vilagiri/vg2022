
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanCashFlow nvarchar(max) ='{
  "name": "COMLLoanCashFlow",
  "description": "Reassembling_BackTrackingAnalysis_LoanCashFlow_Derivatives",
  "sources": [
    {
      "df": "coml_schd_df.Amortization.Payment as schd_payment",
      "period": "d"
    }
  ],
  "joins": [],
  "filters": [],
  "parameters": [],
  "outputs": [
    {
      "fields": [
        {
          "field": "schd_payment.MetLifeAssetID",
          "target": "MetLifeAssetID"
        },
        {
          "default": "COM",
          "target": "LoanCategory"
        },
        {
          "field": "schd_payment.ActualPaymentCurrencyCode",
          "target": "CurrencyCode"
        },
        {
          "default": "LOCAL",
          "target": "CurrencyType"
        },
        {
          "field": "schd_payment.InstallmentDate",
          "target": "InstallmentDate"
        },
        {
          "format": "Decimal(18,2)",
          "field": "schd_payment.BeginPrincipalAmt",
          "target": "BeginPrincipalBalance"
        },
        {
          "format": "Decimal(18,2)",
          "field": "schd_payment.EndPrincipalAmt",
          "target": "EndPrincipalBalance"
        },
        {
          "format": "Decimal(18,2)",
          "calculation": {
            "expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledInterestInstallmentAmt).otherwise(schd_payment.ActualInterestInstallmentAmt)",
            "fields": [ "schd_payment.StatusCode", "schd_payment.ScheduledInterestInstallmentAmt", "schd_payment.ActualInterestInstallmentAmt" ]
          },
          "target": "InterestAmt"
        },
        {
          "format": "Decimal(18,2)",
          "calculation": {
            "expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledPrincipalInstallmentAmt).otherwise(schd_payment.ActualPrincipalInstallmentAmt)",
            "fields": [ "schd_payment.StatusCode", "schd_payment.ScheduledPrincipalInstallmentAmt", "schd_payment.ActualPrincipalInstallmentAmt" ]
          },
          "target": "PrincipalAmt"
        },
        {
          "format": "Decimal(18,2)",
          "calculation": {
            "expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledServiceFeeAmt).otherwise(schd_payment.ActualServiceFeeAmt)",
            "fields": [ "schd_payment.StatusCode", "schd_payment.ScheduledServiceFeeAmt", "schd_payment.ActualServiceFeeAmt" ]
          },
          "target": "ServiceFeeAmt"
        },
        {
          "field": "schd_payment.StatusCode",
          "target": "StatusCode"
        }
      ]
    }
  ]
}'

declare @CashFlowApplicationId int,@CashFlowCommApplicationId int, @CashFlowQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanCashFlow')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('COMLLoanCashFlow','1.0',@COMLLoanCashFlow,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@COMLLoanCashFlow WHERE [QueryDefinitionName]='COMLLoanCashFlow'
END

SELECT @CashFlowApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @CashFlowCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'

SELECT @CashFlowQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanCashFlow'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CashFlowApplicationId AND [QueryDefinitionId] = @CashFlowQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CashFlowApplicationId, @CashFlowQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CashFlowCommApplicationId AND [QueryDefinitionId] = @CashFlowQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CashFlowCommApplicationId, @CashFlowQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH