
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @PortfolioMasterDaily nvarchar(max) ='{
  "name": "PortfolioMasterDaily",
  "description": "",
  "fallback_to_previous_as_of_date": "True",
  "parameters": [
    {
      "parameter": "PRODUCTCODE",
      "type": "string*"
    }
  ],
  "sources": [
    {
      "df": "mast_port_df as port",
      "period": "d"
    }
  ],
  "joins": [],
  "filters": [
    {
      "field": "port.InvestmentProductCode",
      "values": "<PRODUCTCODE>"
    }
  ],
  "outputs": [
    {
      "fields": [
        {
          "field": "port.InvestmentsPortfolioCode",
          "target": "InvestmentsPortfolioCode"
        }
      ]
    }
  ]
}'

declare @PortfolioMasterApplicationId int,@PortfolioMasterCommApplicationId int,  @PortfolioMasterQueryDefinitionId int;

IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='PortfolioMasterDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES		('PortfolioMasterDaily','1.0',@PortfolioMasterDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] set [QueryDefinitionSchema] =@PortfolioMasterDaily 
WHERE [QueryDefinitionName]='PortfolioMasterDaily'
END

SELECT @PortfolioMasterApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @PortfolioMasterCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'
SELECT @PortfolioMasterQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='PortfolioMasterDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PortfolioMasterApplicationId AND [QueryDefinitionId] = @PortfolioMasterQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PortfolioMasterApplicationId, @PortfolioMasterQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PortfolioMasterCommApplicationId AND [QueryDefinitionId] = @PortfolioMasterQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PortfolioMasterCommApplicationId, @PortfolioMasterQueryDefinitionId)
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH