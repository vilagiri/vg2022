
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanHoldingsClient nvarchar(max) ='{
  "name": "COMLLoanHoldingsClient",
  "description": "",
  "parameters": [
    {
      "parameter": "LOANSTATUS",
      "type": "string*"
    },
    {
      "parameter": "REIMANAGEDIND",
      "type": "string*"
    },
    {
      "parameter": "PARTYID",
      "type": "string*"
    }
  ],
  "sources": [
    {
      "df": "13066_DALFI_ComlLoanHoldingsClientDdf as comlclientDdf",
      "period": "d"
    }
  ],
  "filters": [
    {
      "field": "comlclientDdf.LoanStatusCode",
      "values": "<LOANSTATUS>"
    },
    {
      "field": "comlclientDdf.REIManagedInd",
      "values": "<REIMANAGEDIND>"
    },
    {
      "field": "comlclientDdf.MetLifePartyID",
      "values": "<PARTYID>"
    }
  ],
  "joins": [],
  "outputs": [
    {
      "fields": [
        {
          "field": "comlclientDdf.AsOfDate",
          "target": "AsOfDate"
        },
        {
          "field": "comlclientDdf.MetLifePartyName",
          "target": "CompanyName"
        },
        {
          "field": "comlclientDdf.InvestmentsPortfolioCode",
          "target": "PortfolioCode"
        },
        {
          "field": "comlclientDdf.MetLifeAssetID",
          "target": "LoanNumber"
        },
        {
          "field": "comlclientDdf.PropertyName",
          "target": "PropertyName"
        },
        {
          "field": "comlclientDdf.LoanClosedDate",
          "target": "LoanFundedDate"
        },
        {
          "field": "comlclientDdf.MetLifeInterestTypeCode",
          "target": "CouponType"
        },
        {
          "field": "comlclientDdf.LoanPaymentTypeDesc",
          "target": "PaymentMethod"
        },
        {
          "field": "comlclientDdf.InterestReferencedIndexID",
          "target": "FloatingRateIndex"
        },
        {
          "field": "comlclientDdf.ACLIPropertyTypeDesc",
          "target": "PropertyType"
        },
        {
          "field": "comlclientDdf.MSADesc",
          "target": "MSA"
        },
        {
          "field": "comlclientDdf.OutstandingPrincipalBalanceAmt",
          "target": "LoanPrincipalBalance"
        },
        {
          "field": "comlclientDdf.PrincipalBalanceUSD",
          "target": "ClientPrincipalBalance"
        },
        {
          "field": "comlclientDdf.InterestRate",
          "target": "CurrentInterestRate"
        },
        {
          "field": "comlclientDdf.MaturityDate",
          "target": "MaturityDate"
        },
        {
          "field": "comlclientDdf.RaterCode",
          "target": "MortgageRating"
        },
        {
          "field": "comlclientDdf.MetLifeRatingLoanToValueRatio",
          "target": "LTV"
        },
        {
          "field": "comlclientDdf.BaseYearDebtServiceCoverageRatio",
          "target": "BaseYearDSCR"
        }
      ]
    }
  ]
}'

declare @HoldingsClientApplicationId int,@HoldingsClientCommApplicationId int, @HoldingsClientQueryDefinitionId int;

IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanHoldingsClient')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES		('COMLLoanHoldingsClient','1.0',@COMLLoanHoldingsClient,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] set [QueryDefinitionSchema] =@COMLLoanHoldingsClient 
WHERE [QueryDefinitionName]='COMLLoanHoldingsClient'
END

SELECT @HoldingsClientApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @HoldingsClientCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'
SELECT @HoldingsClientQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanHoldingsClient'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@HoldingsClientApplicationId AND [QueryDefinitionId] = @HoldingsClientQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@HoldingsClientApplicationId, @HoldingsClientQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@HoldingsClientCommApplicationId AND [QueryDefinitionId] = @HoldingsClientQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@HoldingsClientCommApplicationId, @HoldingsClientQueryDefinitionId)
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH