
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanCommitmentsFull nvarchar(max) ='{
  "name": "COMLLoanCommitmentsFull",
  "description": "",
  "parameters": [],
  "sources": [
    {
      "df": "coml_cmmt_df as comlcmmt",
      "fallback_to_previous_as_of_date": "True",
      "period": "d"
    }
  ],
  "filters": [],
  "joins": [],
  "outputs": [
    {
      "fields": [
        {
          "target": "ExternalSecurityId",
          "field": "comlcmmt.MetLifeAssetId"
        },
        {
          "target": "AllocationAmount",
          "field": "comlcmmt.UnfundedCommitmentAsset"
        },
        {
          "target": "AllocationDate",
          "field": "comlcmmt.CommitmentDate"
        },
        {
          "target": "AllocatorID",
          "default": "null"
        },
        {
          "target": "CompanyCode",
          "default": "null"
        },
        {
          "target": "Sub-SegCode",
          "field": "comlcmmt.InvestmentsPortfolioCode"
        },
        {
          "target": "USGAAPBookValue",
          "default": "null"
        },
        {
          "target": "USSTATBookValue",
          "default": "null"
        },
        {
          "target": "LocalSTATBookValue",
          "default": "null"
        },
        {
          "target": "HedgeType",
          "default": "null"
        }
      ]
    }
  ]
}'

declare @CommitmentsFullApplicationId int,@CommitmentsFullCommApplicationId int, @CommitmentsFullQueryDefinitionId int;

IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanCommitmentsFull')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('COMLLoanCommitmentsFull','1.0',@COMLLoanCommitmentsFull,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] set [QueryDefinitionSchema] =@COMLLoanCommitmentsFull 
WHERE [QueryDefinitionName]='COMLLoanCommitmentsFull'
END

SELECT @CommitmentsFullApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @CommitmentsFullCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'
SELECT @CommitmentsFullQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanCommitmentsFull'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CommitmentsFullApplicationId AND [QueryDefinitionId] = @CommitmentsFullQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CommitmentsFullApplicationId, @CommitmentsFullQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CommitmentsFullCommApplicationId AND [QueryDefinitionId] = @CommitmentsFullQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CommitmentsFullCommApplicationId, @CommitmentsFullQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH