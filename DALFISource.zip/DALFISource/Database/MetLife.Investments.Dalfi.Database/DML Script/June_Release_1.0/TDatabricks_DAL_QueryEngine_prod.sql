
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_prod nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "DAL_QueryEngine",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://northcentralus.azuredatabricks.net/"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "0205-180316-tawny244"
      },
      {
        "name": "token",
        "value": "PROD.grid.keyVault|PROD-DBRICK0001-TOKEN"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "777388"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @PRODNotebookQueryDefinitionId int

--COMLLoanHoldings
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldings' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanHoldingsDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsDaily' 
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanCashFlow
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlow'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanCashFlowDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlowDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanCommitmentsFull
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFull'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanHoldingsClient
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsClient'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanPrice
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPrice'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END
--PortfolioMaster
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='PortfolioMasterDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanHoldingsMonthly
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanPriceMonthly
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceMonthly'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--MASTPortfolioByProductTypeDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH