
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DALFI_PL_COPY_TO_NAS_dev nvarchar(max) ='{
  "templatetype": "grid_dal_adf_configuration_template",
  "schema": "grid_dal_adf_configuration_template_schema_1.0",
  "definition": {
    "name": "DALFI_PL_COPY_TO_NAS",
    "version": 1.52,
    "configurations": [
      {
        "name": "pipelineName",
        "value": "DALFI_PL_COPY_TO_NAS"
      },
      {
        "name": "resourceGroup",
        "value": "inv-use-dev-dalfi-rg"
      },
      {
        "name": "dataFactoryName",
        "value": "iazedsadf0006"
      },
      {
        "name": "subscriptionId",
        "value": "77b083f7-d8e8-4deb-a6e7-af3e278eae5c"
      },
      {
        "name": "Rule_Normalize__AsOfDate_FM_THIS_IS_NEW",
        "value": "yyyymmdd"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{AsOfDate:<asOfDate>}, {QueryName:<QueryName>}, {EAICode:<EAICode>}, {DataLakePath:<DataLakePath>},{NASPath:\\\\inv.ndcnas.metlife.com\\dev\\13066\\Outgoing\\DDZ\\<eaicode>\\<query>\\<asofdate>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
declare @DEVADFQueryDefinitionId int

--COMLLoanHoldings
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldings' 
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsDaily' 
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCashFlow
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlow'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCashFlowDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCashFlowDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanCommitmentsFull
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFull'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsClient
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsClient'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanPrice
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPrice'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END


--COMLLoanPriceDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--PortfolioMaster
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='PortfolioMasterDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanPriceMonthly
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanPriceMonthly'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanHoldingsMonthly
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanHoldingsMonthly'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPortfolioByProductTypeDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH