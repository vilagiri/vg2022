
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanPrice nvarchar(max) ='{
  "name": "COMLLoanPrice",
  "description": "",
  "parameters": [],
  "sources": [
    {
      "df": "coml_asmt_df as asmt",
      "period": "d"
    },
    {
      "df": "coml_lprc_df as lprc",
      "period": "d"
    }
  ],
  "joins": [
    {
      "leftDf": "asmt",
      "rightDf": "lprc",
      "join": "leftDf.MetLifeAssetID == rightDf.MetLifeAssetID",
      "how": "inner"
    }
  ],
  "filters": [],
  "outputs": [
    {
      "fields": [
        {
          "field": "asmt.MetLifeAssetID",
          "target": "MetLifeAssetID"
        },
        {
          "field": "lprc.PriceDate",
          "target": "EffectiveDate"
        },
        {
          "format": "Decimal(18,2)",
          "field": "asmt.LoanToValueRatio",
          "target": "CurrentLoanToValueRatio"
        },
        {
          "field": "lprc.LoanPrice",
          "target": "BRSPrice"
        },
        {
          "default": "Evaluate",
          "target": "BRSPriceType"
        },
        {
          "field": "asmt.AmortizationStartDate",
          "target": "AmortizationStartDate"
        }
      ]
    }
  ]
}'

declare @PriceApplicationId int,@PriceCommApplicationId int,  @PriceQueryDefinitionId int;

IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanPrice')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES		('COMLLoanPrice','1.0',@COMLLoanPrice,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] set [QueryDefinitionSchema] =@COMLLoanPrice 
WHERE [QueryDefinitionName]='COMLLoanPrice'
END

SELECT @PriceApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @PriceCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'
SELECT @PriceQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanPrice'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceApplicationId AND [QueryDefinitionId] = @PriceQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceApplicationId, @PriceQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceCommApplicationId AND [QueryDefinitionId] = @PriceQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceCommApplicationId, @PriceQueryDefinitionId)
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH