BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

IF NOT EXISTS (SELECT * from dbo.[TEnvironmentReference]  WHERE [EnvironmentName] = 'DEV')
BEGIN 
INSERT INTO [dbo].[TEnvironmentReference]           ([EnvironmentName])
VALUES           ('DEV')
END

IF NOT EXISTS (SELECT * from dbo.[TEnvironmentReference]  WHERE [EnvironmentName] = 'INT')
BEGIN 
INSERT INTO [dbo].[TEnvironmentReference]           ([EnvironmentName])
VALUES           ('INT')
END

IF NOT EXISTS (SELECT * from dbo.[TEnvironmentReference]  WHERE [EnvironmentName] = 'QA')
BEGIN 
INSERT INTO [dbo].[TEnvironmentReference]           ([EnvironmentName])
VALUES           ('QA')
END

IF NOT EXISTS (SELECT * from dbo.[TEnvironmentReference]  WHERE [EnvironmentName] = 'PROD')
BEGIN 
INSERT INTO [dbo].[TEnvironmentReference]           ([EnvironmentName])
VALUES           ('PROD')
END

IF NOT EXISTS (SELECT * from dbo.[TEnvironmentReference]  WHERE [EnvironmentName] = 'DR')
BEGIN 
INSERT INTO [dbo].[TEnvironmentReference]           ([EnvironmentName])
VALUES           ('DR')
END

IF NOT EXISTS (SELECT * from dbo.[TApplicationReference]  WHERE [ApplicationName] = 'PROOF')
BEGIN 
INSERT INTO [dbo].[TApplicationReference] ([ApplicationName]           ,[EAICode])
VALUES			 ('PROOF',12276)
END

IF NOT EXISTS (SELECT * from dbo.[TApplicationReference]  WHERE [ApplicationName] = 'GRID')
BEGIN 
INSERT INTO [dbo].[TApplicationReference] ([ApplicationName]           ,[EAICode])
VALUES			 ('GRID',12096)
END

IF NOT EXISTS (SELECT * from dbo.[TApplicationReference]  WHERE [ApplicationName] = 'DALFI')
BEGIN 
INSERT INTO [dbo].[TApplicationReference] ([ApplicationName]           ,[EAICode])
VALUES			 ('DALFI',13066)
END

IF NOT EXISTS (SELECT * from dbo.[TApplicationReference]  WHERE [ApplicationName] = 'COMMERCIAL')
BEGIN 
INSERT INTO [dbo].[TApplicationReference] ([ApplicationName]           ,[EAICode])
VALUES			 ('COMMERCIAL',7265)
END

IF NOT EXISTS (SELECT * from dbo.[TApplicationReference]  WHERE [ApplicationName] = 'ALTERYX')
BEGIN 
INSERT INTO [dbo].[TApplicationReference] ([ApplicationName]           ,[EAICode])
VALUES			 ('ALTERYX',12125)
END


COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH

		   	
	
	


