
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DALFI_PL_COPY_TO_NAS_dev nvarchar(max) ='{
  "templatetype": "grid_dal_adf_configuration_template",
  "schema": "grid_dal_adf_configuration_template_schema_1.0",
  "definition": {
    "name": "DALFI_PL_COPY_TO_NAS",
    "version": 1.52,
    "configurations": [
      {
        "name": "pipelineName",
        "value": "DALFI_PL_COPY_TO_NAS"
      },
      {
        "name": "resourceGroup",
        "value": "inv-use-dev-dalfi-rg"
      },
      {
        "name": "dataFactoryName",
        "value": "iazedsadf0006"
      },
      {
        "name": "subscriptionId",
        "value": "77b083f7-d8e8-4deb-a6e7-af3e278eae5c"
      },
      {
        "name": "Rule_Normalize__AsOfDate_FM_THIS_IS_NEW",
        "value": "yyyymmdd"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{AsOfDate:<asOfDate>}, {QueryName:<QueryName>}, {EAICode:<EAICode>}, {DataLakePath:<DataLakePath>},{NASPath:\\\\inv.ndcnas.metlife.com\\dev\\13066\\Outgoing\\DDZ\\<eaicode>\\<query>\\<asofdate>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
declare @DEVADFQueryDefinitionId int

--COMLLoanCommitmentsFullDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFullDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPersonPartyDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPortfolioByProductTypeDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanTransactionDaily
 SELECT @DEVADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanTransactionDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('DEV',@DEVADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_dev)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_dev 
WHERE QueryDefinitionId=@DEVADFQueryDefinitionId and EnvironmentName ='DEV'
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH