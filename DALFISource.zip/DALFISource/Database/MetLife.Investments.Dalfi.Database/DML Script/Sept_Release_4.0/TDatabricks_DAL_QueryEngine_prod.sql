
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_prod nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "DAL_QueryEngine",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://northcentralus.azuredatabricks.net/"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "0205-180316-tawny244"
      },
      {
        "name": "token",
        "value": "PROD.grid.keyVault|PROD-DBRICK0001-TOKEN"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "777388"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @PRODNotebookQueryDefinitionId int


--COMLLoanCommitmentsFullDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFullDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--MASTPersonPartyDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--MASTPortfolioByProductTypeDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanTransactionDaily
 SELECT @PRODNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanTransactionDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('PROD',@PRODNotebookQueryDefinitionId, @DAL_QueryEngine_prod)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_prod 
WHERE QueryDefinitionId=@PRODNotebookQueryDefinitionId and EnvironmentName ='PROD'
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH