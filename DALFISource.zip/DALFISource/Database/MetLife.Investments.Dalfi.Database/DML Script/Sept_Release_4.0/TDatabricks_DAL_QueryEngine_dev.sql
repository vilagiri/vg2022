
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_dev nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "GRID_DAL",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://eastus.azuredatabricks.net"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "0608-155640-alit27"
      },
      {
        "name": "token",
        "value": "Dev.grid.keyVault|Dev-Databricks-Token"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "20540"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @DEVNotebookQueryDefinitionId int


--COMLLoanCommitmentsFullDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFullDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPortfolioByProductTypeDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPersonPartyDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--MASTPersonPartyDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END

--COMLLoanTransactionDaily
 SELECT @DEVNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanTransactionDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DEV',@DEVNotebookQueryDefinitionId, @DAL_QueryEngine_dev)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dev 
WHERE QueryDefinitionId=@DEVNotebookQueryDefinitionId and EnvironmentName ='DEV'
END


COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH