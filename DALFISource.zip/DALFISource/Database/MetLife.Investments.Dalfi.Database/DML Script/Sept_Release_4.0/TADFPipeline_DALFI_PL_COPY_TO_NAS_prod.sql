
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DALFI_PL_COPY_TO_NAS_prod nvarchar(max) ='{
  "templatetype": "grid_dal_adf_configuration_template",
  "schema": "grid_dal_adf_configuration_template_schema_1.0",
  "definition": {
    "name": "DALFI_PL_COPY_TO_NAS",
    "version": 1.52,
    "configurations": [
      {
        "name": "pipelineName",
        "value": "DALFI_PL_COPY_TO_NAS"
      },
      {
        "name": "resourceGroup",
        "value": "inv-usnc-prod-dalfi-rg"
      },
      {
        "name": "dataFactoryName",
        "value": "iazncpsadf0006"
      },
      {
        "name": "subscriptionId",
        "value": "117ce6a3-1c6d-4c88-a40d-1566b1f8d591"
      },
      {
        "name": "Rule_Normalize__AsOfDate_FM_THIS_IS_NEW",
        "value": "yyyymmdd"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{AsOfDate:<asOfDate>}, {QueryName:<QueryName>}, {EAICode:<EAICode>}, {DataLakePath:<DataLakePath>},{NASPath:\\\\inv.cdcnas.metlife.com\\prod\\13066\\Outgoing\\DDZ\\<eaicode>\\<query>\\<asofdate>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'


declare @PRODADFQueryDefinitionId int

--COMLLoanCommitmentsFullDaily
 SELECT @PRODADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFullDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('PROD',@PRODADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_prod)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_prod 
WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD'
END

--MASTPersonPartyDaily
 SELECT @PRODADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('PROD',@PRODADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_prod)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_prod 
WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD'
END
--MASTPortfolioByProductTypeDaily
 SELECT @PRODADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('PROD',@PRODADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_prod)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_prod 
WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD'
END

--COMLLoanTransactionDaily
 SELECT @PRODADFQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanTransactionDaily'
IF NOT EXISTS (SELECT * from dbo.TADFPipelineSchema  WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD')
BEGIN 
Insert into dbo.TADFPipelineSchema (  EnvironmentName,	QueryDefinitionId,	ADFPipelineSchema) 
  values
	  ('PROD',@PRODADFQueryDefinitionId, @DALFI_PL_COPY_TO_NAS_prod)
END

ELSE
BEGIN 
update dbo.TADFPipelineSchema set ADFPipelineSchema =@DALFI_PL_COPY_TO_NAS_prod 
WHERE QueryDefinitionId=@PRODADFQueryDefinitionId and EnvironmentName ='PROD'
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH