
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanPriceMonthly nvarchar(max) ='{"name": "COMLLoanPriceMonthly", "description": "", "parameters": [{"parameter": "LOANSTATUS", "type": "string*"}, {"parameter": "REIMANAGEDIND", "type": "string*"}, {"parameter": "METLIFEASSETID", "type": "string*"}], "sources": [{"df": "coml_asmt_df as asmt", "period": "m"}, {"df": "coml_lprc_df as lprc", "period": "m"}], "joins": [{"leftDf": "asmt", "rightDf": "lprc", "join": "leftDf.MetLifeAssetID == rightDf.MetLifeAssetID", "how": "inner"}], "filters": [{"field": "asmt.LoanStatusCode", "values": "<LOANSTATUS>"}, {"field": "asmt.REIManagedInd", "values": "<REIMANAGEDIND>"}, {"field": "asmt.MetLifeAssetID", "values": "<METLIFEASSETID>"}], "outputs": [{"fields": [{"field": "asmt.MetLifeAssetID", "target": "MetLifeAssetID"}, {"field": "lprc.PriceDate", "target": "EffectiveDate"}, {"format": "Decimal(18,2)", "field": "asmt.LoanToValueRatio", "target": "CurrentLoanToValueRatio"}, {"field": "lprc.LoanPrice", "target": "BRSPrice"}, {"default": "Evaluate", "target": "BRSPriceType"}, {"field": "asmt.AmortizationStartDate", "target": "AmortizationStartDate"}]}]}'

declare @PriceMonthlyApplicationId int,@PriceMonthlyCommApplicationId int, @PriceMonthlyQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanPriceMonthly')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('COMLLoanPriceMonthly','1.0',@COMLLoanPriceMonthly,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@COMLLoanPriceMonthly WHERE [QueryDefinitionName]='COMLLoanPriceMonthly'
END

SELECT @PriceMonthlyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @PriceMonthlyCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'

SELECT @PriceMonthlyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanPriceMonthly'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceMonthlyApplicationId AND [QueryDefinitionId] = @PriceMonthlyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceMonthlyApplicationId, @PriceMonthlyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@PriceMonthlyCommApplicationId AND [QueryDefinitionId] = @PriceMonthlyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@PriceMonthlyCommApplicationId, @PriceMonthlyQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH