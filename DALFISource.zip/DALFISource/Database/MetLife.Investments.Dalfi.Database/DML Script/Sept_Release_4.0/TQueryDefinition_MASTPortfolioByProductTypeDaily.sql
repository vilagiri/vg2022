
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @MASTPortfolioByProductTypeDaily nvarchar(max) ='{"name": "MASTPortfolioByProductTypeDaily", "fallback_to_previous_as_of_date": "True","description": "", "parameters": [{"parameter": "PRODUCTTYPENAME", "type": "string*"}], "sources": [{"df": "mast_port_df as port", "fallback_to_previous_as_of_date": "True", "period": "d"}, {"df": "mast_prdt_df as prdt", "fallback_to_previous_as_of_date": "True", "period": "d"}], "joins": [{"leftDf": "port", "rightDf": "prdt", "join": "leftDf.InvestmentProductCode == rightDf.InvestmentProductCode", "how": "inner"}], "filters": [{"field": "prdt.InvestmentProductTypeName", "values": "<PRODUCTTYPENAME>"}], "outputs": [{"fields": [{"field": "port.InvestmentsPortfolioCode", "target": "InvestmentsPortfolioCode"}]}]}'

declare @MASTPortfolioByProductTypeDailyApplicationId int,@AlteryxApplicationId int, @MASTPortfolioByProductTypeDailyQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='MASTPortfolioByProductTypeDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('MASTPortfolioByProductTypeDaily','1.0',@MASTPortfolioByProductTypeDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@MASTPortfolioByProductTypeDaily WHERE [QueryDefinitionName]='MASTPortfolioByProductTypeDaily'
END

SELECT @MASTPortfolioByProductTypeDailyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @AlteryxApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'ALTERYX'

SELECT @MASTPortfolioByProductTypeDailyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='MASTPortfolioByProductTypeDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@MASTPortfolioByProductTypeDailyApplicationId AND [QueryDefinitionId] = @MASTPortfolioByProductTypeDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@MASTPortfolioByProductTypeDailyApplicationId, @MASTPortfolioByProductTypeDailyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@AlteryxApplicationId AND [QueryDefinitionId] = @MASTPortfolioByProductTypeDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@AlteryxApplicationId, @MASTPortfolioByProductTypeDailyQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH