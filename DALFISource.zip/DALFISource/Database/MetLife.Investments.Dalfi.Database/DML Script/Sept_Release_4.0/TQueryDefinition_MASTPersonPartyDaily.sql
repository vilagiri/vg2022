
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @MASTPersonPartyDaily nvarchar(max) ='{"name": "MASTPersonPartyDaily", "description": "", "sources": [{"df": "mast_prpt_df as prpt", "fallback_to_previous_as_of_date": "True", "period": "d"}], "joins": [], "parameters": [], "filters": [], "outputs": [{"fields": [{"field": "prpt.PartyClassCode", "target": "PartyClassCode"}, {"field": "prpt.MetLifePartyID", "target": "MetLifePartyID"}, {"field": "prpt.EmailAddress", "target": "EmailAddress"}, {"field": "prpt.EmploymentStatusCode", "target": "EmploymentStatusCode"}]}]}'

declare @MASTPersonPartyDailyApplicationId int,@MASTPersonPartyDailyCommApplicationId int, @MASTPersonPartyDailyQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='MASTPersonPartyDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('MASTPersonPartyDaily','1.0',@MASTPersonPartyDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@MASTPersonPartyDaily WHERE [QueryDefinitionName]='MASTPersonPartyDaily'
END

SELECT @MASTPersonPartyDailyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @MASTPersonPartyDailyCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'

SELECT @MASTPersonPartyDailyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='MASTPersonPartyDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@MASTPersonPartyDailyApplicationId AND [QueryDefinitionId] = @MASTPersonPartyDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@MASTPersonPartyDailyApplicationId, @MASTPersonPartyDailyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@MASTPersonPartyDailyCommApplicationId AND [QueryDefinitionId] = @MASTPersonPartyDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@MASTPersonPartyDailyCommApplicationId, @MASTPersonPartyDailyQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH