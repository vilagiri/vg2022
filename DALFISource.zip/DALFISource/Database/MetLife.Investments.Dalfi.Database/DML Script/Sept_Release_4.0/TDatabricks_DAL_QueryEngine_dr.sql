
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY
declare @DAL_QueryEngine_dr nvarchar(max) ='{
  "templatetype": "grid_dal_configuration_template",
  "schema": "grid_dal_configuration_template_schema_1.0",
  "definition": {
    "name": "DAL_QueryEngine",
    "version": 1,
    "configurations": [
      {
        "name": "context",
        "value": "GRID_DAL"
      },
      {
        "name": "baseUrl",
        "value": "https://southcentralus.azuredatabricks.net/"
      },
      {
        "name": "NotebookPath",
        "value": "/13066_DALFI/QueryEngine/Caller_Query_Engine"
      },
      {
        "name": "ClusterID",
        "value": "0323-135416-scald44"
      },
      {
        "name": "token",
        "value": "PROD.grid.keyVault|DR-dbrick0001-TOKEN"
      },
      {
        "name": "JobName",
        "value": "DAL_QueryEngine"
      },
      {
        "name": "JobID",
        "value": "283"
      },
      {
        "name": "WorkerTimeout",
        "value": "2700000"
      },
      {
        "name": "InParameters",
        "value": "[{queryDefinition:<queryDefinition>},  {payLoad:<payLoad>}, {queryInstanceID:<queryInstanceID>}]"
      },
      {
        "name": "OutParameters",
        "value": "[{status:<status>}]"
      }
    ]
  }
}'
	
declare @DRNotebookQueryDefinitionId int




--COMLLoanCommitmentsFullDaily
 SELECT @DRNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanCommitmentsFullDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DR',@DRNotebookQueryDefinitionId, @DAL_QueryEngine_dr)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dr 
WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR'
END

--MASTPortfolioByProductTypeDaily
 SELECT @DRNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPortfolioByProductTypeDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DR',@DRNotebookQueryDefinitionId, @DAL_QueryEngine_dr)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dr 
WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR'
END

--MASTPersonPartyDaily
 SELECT @DRNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='MASTPersonPartyDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DR',@DRNotebookQueryDefinitionId, @DAL_QueryEngine_dr)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dr 
WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR'
END

--COMLLoanTransactionDaily
 SELECT @DRNotebookQueryDefinitionId = QueryDefinitionId from dbo.TQueryDefinition WHERE QueryDefinitionName='COMLLoanTransactionDaily'
IF NOT EXISTS (SELECT * from dbo.TDatabrickNotebookSchema  WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR')
BEGIN 
Insert into dbo.TDatabrickNotebookSchema (  EnvironmentName,	QueryDefinitionId,	DatabrickNotebookSchema) 
  values
	  ('DR',@DRNotebookQueryDefinitionId, @DAL_QueryEngine_dr)
END

ELSE
BEGIN 
update dbo.TDatabrickNotebookSchema set DatabrickNotebookSchema =@DAL_QueryEngine_dr 
WHERE QueryDefinitionId=@DRNotebookQueryDefinitionId and EnvironmentName ='DR'
END
COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH