
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanCashFlowDaily nvarchar(max) ='{"name": "COMLLoanCashFlowDaily", "description": "Reassembling_BackTrackingAnalysis_LoanCashFlow_Derivatives", "sources": [{"df": "coml_schd_df.Amortization.Payment as schd_payment", "period": "d"}, {"df": "coml_asmt_df as asmt", "period": "d"}], "joins": [{"leftDf": "asmt", "rightDf": "schd_payment", "join": "leftDf.MetLifeAssetID == rightDf.MetLifeAssetID", "how": "inner"}], "parameters": [{"parameter": "LOANSTATUS", "type": "string*"}, {"parameter": "REIMANAGEDIND", "type": "string*"}, {"parameter": "METLIFEASSETID", "type": "string*"}], "filters": [{"field": "asmt.LoanStatusCode", "values": "<LOANSTATUS>"}, {"field": "asmt.REIManagedInd", "values": "<REIMANAGEDIND>"}, {"field": "asmt.MetLifeAssetID", "values": "<METLIFEASSETID>"}], "outputs": [{"fields": [{"field": "schd_payment.MetLifeAssetID", "target": "MetLifeAssetID"}, {"default": "COM", "target": "LoanCategory"}, {"field": "schd_payment.ActualPaymentCurrencyCode", "target": "CurrencyCode"}, {"default": "LOCAL", "target": "CurrencyType"}, {"field": "schd_payment.InstallmentDate", "target": "InstallmentDate"}, {"format": "Decimal(18,2)", "field": "schd_payment.BeginPrincipalAmt", "target": "BeginPrincipalBalance"}, {"format": "Decimal(18,2)", "field": "schd_payment.EndPrincipalAmt", "target": "EndPrincipalBalance"}, {"format": "Decimal(18,2)", "calculation": {"expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledInterestInstallmentAmt).otherwise(schd_payment.ActualInterestInstallmentAmt)", "fields": ["schd_payment.StatusCode", "schd_payment.ScheduledInterestInstallmentAmt", "schd_payment.ActualInterestInstallmentAmt"]}, "target": "InterestAmt"}, {"format": "Decimal(18,2)", "calculation": {"expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledPrincipalInstallmentAmt).otherwise(schd_payment.ActualPrincipalInstallmentAmt)", "fields": ["schd_payment.StatusCode", "schd_payment.ScheduledPrincipalInstallmentAmt", "schd_payment.ActualPrincipalInstallmentAmt"]}, "target": "PrincipalAmt"}, {"format": "Decimal(18,2)", "calculation": {"expression": "when(schd_payment.StatusCode == ''U'', schd_payment.ScheduledServiceFeeAmt).otherwise(schd_payment.ActualServiceFeeAmt)", "fields": ["schd_payment.StatusCode", "schd_payment.ScheduledServiceFeeAmt", "schd_payment.ActualServiceFeeAmt"]}, "target": "ServiceFeeAmt"}, {"field": "schd_payment.StatusCode", "target": "StatusCode"}]}]}'

declare @CashFlowDailyApplicationId int,@CashFlowDailyCommApplicationId int, @CashFlowDailyQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanCashFlowDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('COMLLoanCashFlowDaily','1.0',@COMLLoanCashFlowDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@COMLLoanCashFlowDaily WHERE [QueryDefinitionName]='COMLLoanCashFlowDaily'
END

SELECT @CashFlowDailyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @CashFlowDailyCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'

SELECT @CashFlowDailyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanCashFlowDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CashFlowDailyApplicationId AND [QueryDefinitionId] = @CashFlowDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CashFlowDailyApplicationId, @CashFlowDailyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@CashFlowDailyCommApplicationId AND [QueryDefinitionId] = @CashFlowDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@CashFlowDailyCommApplicationId, @CashFlowDailyQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH