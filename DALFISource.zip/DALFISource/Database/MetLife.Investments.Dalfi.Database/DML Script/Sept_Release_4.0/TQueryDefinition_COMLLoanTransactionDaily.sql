
BEGIN TRAN 
SET NOCOUNT ON
BEGIN TRY

declare @COMLLoanTransactionDaily nvarchar(max) ='{"name": "COMLLoanTransactionDaily", "description": "", "parameters": [], "sources": [{"df": "coml_trns_df as trns", "period": "d"}, {"df": "coml_trns_df.AccountingBasis as coml_trns_accounting_gaap", "period": "d"}], "joins": [{"how": "inner", "rightDf": "coml_trns_accounting_gaap", "leftDf": "trns", "join": ["MetLifeAssetID", "InvestmentsPortfolioCode"]}], "filters": [{"field": "coml_trns_accounting_gaap.AccountingBasisCode", "values": "GAAP"}], "outputs": [{"fields": [{"field": "trns.SourceSystemTransactionId", "target": "TransactionID"}, {"field": "trns.ActualSettlementDate", "target": "ActualSettlementDate"}, {"field": "trns.MetLifeAssetID", "target": "ExternalSecurityID"}, {"field": "coml_trns_accounting_gaap.BookValueChangeUSD", "target": "GAAPBookValChangedUSD"}, {"field": "trns.TransactionStatusCode", "target": "NewChgDelPurInd"}, {"field": "trns.InvestmentsPortfolioCode", "target": "PortfolioCode"}, {"field": "trns.TradePrice", "target": "Price"}, {"field": "trns.AdvancePrincipalPaymentAsset", "target": "PrincipalRepaid"}, {"field": "trns.ContractualSettlementDate", "target": "SettleDate"}, {"field": "trns.DataSystemCode", "target": "Source"}, {"field": "trns.NetTransactionAmtUSD", "target": "TotalAmountUSD"}, {"field": "coml_trns_accounting_gaap.AccountingPostDate", "target": "TradeAccountingDate"}, {"field": "trns.TransactionDate", "target": "TransDate"}, {"field": "trns.SourceSystemTransactionCategoryCode", "target": "TransGroup"}, {"field": "trns.SourceSystemTransactionTypeCode", "target": "TransType"}, {"field": "trns.UnscheduledpaymentInd", "target": "UnscheduledRepaymentInd"}, {"field": "coml_trns_accounting_gaap.AccruedDiscountUSD", "target": "AMZDiscountIncomeUSD"}, {"field": "coml_trns_accounting_gaap.AmortizedPremiumUSD", "target": "AMZPremiumExpenseUSD"}, {"field": "trns.AccruedInterestUSD", "target": "AccruedInterestChangeUSD"}, {"field": "trns.InterestPaymentUSD", "target": "InterestIncomeUSD"}, {"field": "coml_trns_accounting_gaap.OtherInvestmentIncomeUSD", "target": "OtherInvestmentIncomeUSD"}, {"field": "coml_trns_accounting_gaap.UnrealizedFXGainLossUSD", "target": "UnrealizedFXRateGainLossUSD"}, {"field": "coml_trns_accounting_gaap.VariableIncomeUSD", "target": "VolatileInvIncomeUSD"}, {"field": "coml_trns_accounting_gaap.RealizedMarketGainLossUSD", "target": "GAAPRealMktGainLossUSD"}, {"field": "coml_trns_accounting_gaap.RealizedFXGainLossUSD", "target": "GAAPRealExRateGainLossUSD"}, {"field": "trns.TradeEffectiveDuration", "target": "Duration"}, {"field": "trns.TradeConvexity", "target": "Convexity"}, {"field": "coml_trns_accounting_gaap.BookYield", "target": "BookYieldDenominated"}, {"field": "coml_trns_accounting_gaap.BookValueChangePortfolio", "target": "GAAPBookValChangedFunctional"}, {"field": "coml_trns_accounting_gaap.BookValueChangeAsset", "target": "GAAPBookValChangedDenominated"}, {"field": "trns.NetTransactionAmtPortfolio", "target": "TotalAmountFunctional"}, {"field": "trns.NetTransactionAmtAsset", "target": "TotalAmountDenominated"}, {"field": "coml_trns_accounting_gaap.AccruedDiscountPortfolio", "target": "AMZDiscountIncomeFunctional"}, {"field": "coml_trns_accounting_gaap.AccruedDiscountAsset", "target": "AMZDiscountIncomeDenominated"}, {"field": "coml_trns_accounting_gaap.AmortizedPremiumPortfolio", "target": "AMZPremiumExpenseFunctional"}, {"field": "coml_trns_accounting_gaap.AmortizedPremiumAsset", "target": "AMZPremiumExpenseDenominated"}, {"field": "trns.AccruedInterestPortfolio", "target": "AccruedInterestChangeFunctional"}, {"field": "trns.AccruedInterestAsset", "target": "AccruedInterestChangeDenominated"}, {"field": "trns.InterestPaymentPortfolio", "target": "InterestIncomeFunctional"}, {"field": "trns.InterestPaymentAsset", "target": "InterestIncomeDenominated"}, {"field": "coml_trns_accounting_gaap.OtherInvestmentIncomePortfolio", "target": "OtherInvestmentIncomeFunctional"}, {"field": "coml_trns_accounting_gaap.OtherInvestmentIncomeAsset", "target": "OtherInvestmentIncomeDenominated"}, {"field": "coml_trns_accounting_gaap.UnrealizedFXGainLossPortfolio", "target": "UnrealizedFXRateGainLossFunctional"}, {"field": "coml_trns_accounting_gaap.UnrealizedFXGainLossAsset", "target": "UnrealizedFXRateGainLossDenominated"}, {"field": "coml_trns_accounting_gaap.VariableIncomePortfolio", "target": "VolatileInvIncomeFunctional"}, {"field": "coml_trns_accounting_gaap.VariableIncomeAsset", "target": "VolatileInvIncomeDenominated"}, {"field": "coml_trns_accounting_gaap.RealizedMarketGainLossPortfolio", "target": "GAAPRealMktGainLossFunctional"}, {"field": "coml_trns_accounting_gaap.RealizedMarketGainLossAsset", "target": "GAAPRealMktGainLossDenominated"}, {"field": "coml_trns_accounting_gaap.RealizedFXGainLossPortfolio", "target": "GAAPRealExRateGainLossFunctional"}, {"field": "coml_trns_accounting_gaap.RealizedFXGainLossAsset", "target": "GAAPRealExRateGainLossDenominated"}, {"field": "trns.AssetTeamName", "target": "AssetTeamName"}, {"field": "trns.ClientTransactionGroupCode", "target": "ClientTransactionGroupCode"}, {"field": "trns.UserDefinedTransactionTypeDesc", "target": "UserDefinedTransactionTypeDesc"}]}]}'

declare @TransactionDailyApplicationId int,@TransactionDailyCommApplicationId int, @TransactionDailyQueryDefinitionId int;


IF NOT EXISTS (SELECT * from dbo.[TQueryDefinition]  WHERE [QueryDefinitionName]='COMLLoanTransactionDaily')
BEGIN 
INSERT INTO [dbo].[TQueryDefinition]
           ([QueryDefinitionName],[VersionCode],[QueryDefinitionSchema],[VersionStartDate],[DefaultDeliveryMethodName])
VALUES	('COMLLoanTransactionDaily','1.0',@COMLLoanTransactionDaily,'2020-01-15','Stream')

END

ELSE
BEGIN 
UPDATE dbo.[TQueryDefinition] 
set [QueryDefinitionSchema] =@COMLLoanTransactionDaily WHERE [QueryDefinitionName]='COMLLoanTransactionDaily'
END

SELECT @TransactionDailyApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'DALFI'
SELECT @TransactionDailyCommApplicationId =  ApplicationId FROM TApplicationReference where [ApplicationName] = 'COMMERCIAL'

SELECT @TransactionDailyQueryDefinitionId =  [QueryDefinitionId] FROM [TQueryDefinition] where [QueryDefinitionName]='COMLLoanTransactionDaily'

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@TransactionDailyApplicationId AND [QueryDefinitionId] = @TransactionDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@TransactionDailyApplicationId, @TransactionDailyQueryDefinitionId)
END

IF NOT EXISTS (SELECT * from dbo.[TQueryApplicationPermission]  WHERE [ApplicationId]=@TransactionDailyCommApplicationId AND [QueryDefinitionId] = @TransactionDailyQueryDefinitionId)
BEGIN 
INSERT INTO [dbo].[TQueryApplicationPermission] ([ApplicationId],[QueryDefinitionId])
VALUES	(@TransactionDailyCommApplicationId, @TransactionDailyQueryDefinitionId)
END

COMMIT TRAN
END TRY

BEGIN CATCH
       Print 'Script Failed'
       Print 'Line Number # ' + cast (Error_Line () as varchar(10))
       Print Error_Message()
       Rollback TRAN
END CATCH