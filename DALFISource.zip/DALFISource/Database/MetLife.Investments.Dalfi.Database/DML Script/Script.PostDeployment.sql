﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								2
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanCashFlowDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanTransactionDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanCommitmentsFullDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanHoldingsDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanHoldingsMonthly.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanPriceDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_COMLLoanPriceMonthly.sql
:r .\Sept_Release_4.0\TQueryDefinition_MASTPersonPartyDaily.sql
:r .\Sept_Release_4.0\TQueryDefinition_MASTPortfolioByProductTypeDaily.sql
:r .\Sept_Release_4.0\TADFPipeline_DALFI_PL_COPY_TO_NAS_dev.sql
:r .\Sept_Release_4.0\TADFPipeline_DALFI_PL_COPY_TO_NAS_dr.sql
:r .\Sept_Release_4.0\TADFPipeline_DALFI_PL_COPY_TO_NAS_int.sql
:r .\Sept_Release_4.0\TADFPipeline_DALFI_PL_COPY_TO_NAS_prod.sql
:r .\Sept_Release_4.0\TADFPipeline_DALFI_PL_COPY_TO_NAS_qa.sql
:r .\Sept_Release_4.0\TDatabricks_DAL_QueryEngine_dev.sql
:r .\Sept_Release_4.0\TDatabricks_DAL_QueryEngine_dr.sql
:r .\Sept_Release_4.0\TDatabricks_DAL_QueryEngine_int.sql
:r .\Sept_Release_4.0\TDatabricks_DAL_QueryEngine_prod.sql
:r .\Sept_Release_4.0\TDatabricks_DAL_QueryEngine_qa.sql


