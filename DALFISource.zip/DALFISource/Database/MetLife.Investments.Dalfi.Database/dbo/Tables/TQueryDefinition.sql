﻿CREATE TABLE [dbo].[TQueryDefinition] (
    [QueryDefinitionId]         INT            IDENTITY (1, 1) NOT NULL,
    [QueryDefinitionName]       NVARCHAR (255) NOT NULL,
    [VersionCode]               NVARCHAR (20)  NOT NULL,
    [QueryDefinitionSchema]     NVARCHAR (MAX) NOT NULL,
    [VersionStartDate]          DATE           NOT NULL,
    [VersionEndDate]            DATE           NULL,
    [DefaultDeliveryMethodName] NVARCHAR (255) NOT NULL,
    [ADFPipelineName]           NVARCHAR (255) NULL,
    [DatabrickNotebookName]     NVARCHAR (255) NULL,
    CONSTRAINT [PKTQueryDefinition] PRIMARY KEY CLUSTERED ([QueryDefinitionId] ASC),
    CONSTRAINT [AK1TQueryDefinition] UNIQUE NONCLUSTERED ([QueryDefinitionName] ASC, [VersionCode] ASC),
    CONSTRAINT [AK2TQueryDefinition] UNIQUE NONCLUSTERED ([QueryDefinitionName] ASC, [VersionStartDate] ASC)
);



