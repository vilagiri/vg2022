﻿CREATE TABLE [dbo].[TQueryApplicationPermission] (
    [ApplicationId]     INT NOT NULL,
    [QueryDefinitionId] INT NOT NULL,
    CONSTRAINT [PKTQueryApplicationPermission] PRIMARY KEY CLUSTERED ([ApplicationId] ASC, [QueryDefinitionId] ASC),
    CONSTRAINT [FKpdboTApplicationReferencecdboTQueryApplicationPermission] FOREIGN KEY ([ApplicationId]) REFERENCES [dbo].[TApplicationReference] ([ApplicationId]),
    CONSTRAINT [FKpTQueryDefinitioncTQueryApplicationPermission] FOREIGN KEY ([QueryDefinitionId]) REFERENCES [dbo].[TQueryDefinition] ([QueryDefinitionId])
);

