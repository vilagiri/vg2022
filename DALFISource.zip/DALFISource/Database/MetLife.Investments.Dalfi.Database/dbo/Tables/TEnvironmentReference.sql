﻿CREATE TABLE [dbo].[TEnvironmentReference] (
    [EnvironmentName] NVARCHAR (20) NOT NULL,
    CONSTRAINT [PKTEnvironmentReference] PRIMARY KEY CLUSTERED ([EnvironmentName] ASC)
);

