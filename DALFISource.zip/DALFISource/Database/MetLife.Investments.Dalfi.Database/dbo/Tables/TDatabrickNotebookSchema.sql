﻿CREATE TABLE [dbo].[TDatabrickNotebookSchema] (
    [EnvironmentName]         NVARCHAR (20)  NOT NULL,
    [QueryDefinitionId]       INT            NOT NULL,
    [DatabrickNotebookSchema] NVARCHAR (MAX) NOT NULL,
    CONSTRAINT [PKTDatabrickNotebookSchema] PRIMARY KEY CLUSTERED ([EnvironmentName] ASC, [QueryDefinitionId] ASC),
    CONSTRAINT [FKpTEnvironmentReferencecTDatabrickNotebookSchema] FOREIGN KEY ([EnvironmentName]) REFERENCES [dbo].[TEnvironmentReference] ([EnvironmentName]),
    CONSTRAINT [FKpTQueryDefinitioncTDatabrickNotebookSchema] FOREIGN KEY ([QueryDefinitionId]) REFERENCES [dbo].[TQueryDefinition] ([QueryDefinitionId])
);

