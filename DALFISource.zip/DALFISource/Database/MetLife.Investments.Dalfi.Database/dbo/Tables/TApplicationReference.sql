﻿CREATE TABLE [dbo].[TApplicationReference] (
    [ApplicationId]      INT            IDENTITY (1, 1) NOT NULL,
    [ApplicationName]    NVARCHAR (255) NOT NULL,
    [EAICode]            INT            NULL,
    [ThirdPartyOwnedInd] NCHAR (1)      NULL,
    CONSTRAINT [PKTApplicationReference] PRIMARY KEY CLUSTERED ([ApplicationId] ASC),
    CONSTRAINT [CKInd_1345487407] CHECK ([ThirdPartyOwnedInd]='N' OR [ThirdPartyOwnedInd]='Y'),
    CONSTRAINT [AK1TApplicationReference] UNIQUE NONCLUSTERED ([ApplicationName] ASC)
);

