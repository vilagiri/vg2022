﻿CREATE TABLE [dbo].[TQueryInstanceStatusLog] (
    [QueryInstanceStatusLogId] INT            IDENTITY (1, 1) NOT NULL,
    [LogMessage]               NVARCHAR (MAX) NULL,
    [QueryInstanceId]          INT            NOT NULL,
    [ProcessingStatusName]     NVARCHAR (50)  NOT NULL,
    [LogEntryTimestamp]        DATETIME       NOT NULL,
    CONSTRAINT [PKTQueryInstanceStatusLog] PRIMARY KEY CLUSTERED ([QueryInstanceStatusLogId] ASC),
    CONSTRAINT [AK1TQueryInstanceStatusLog] UNIQUE NONCLUSTERED ([QueryInstanceId] ASC, [LogEntryTimestamp] ASC)
);

