﻿CREATE TABLE [dbo].[TQueryReadiness] (
    [QueryDefinitionId]          INT      NOT NULL,
    [DataAsOfDate]               DATETIME NOT NULL,
    [PROOFNotifiedAvailableTime] DATETIME NOT NULL,
    CONSTRAINT [PKTQueryReadiness] PRIMARY KEY CLUSTERED ([QueryDefinitionId] ASC, [DataAsOfDate] ASC, [PROOFNotifiedAvailableTime] ASC),
    CONSTRAINT [FKpTQueryDefinitioncTQueryReadiness] FOREIGN KEY ([QueryDefinitionId]) REFERENCES [dbo].[TQueryDefinition] ([QueryDefinitionId])
);

