﻿CREATE TABLE [dbo].[TQueryInstance] (
    [QueryInstanceId]             INT            IDENTITY (1, 1) NOT NULL,
    [QueryInstanceInputSchema]    NVARCHAR (MAX) NULL,
    [QueryDefinitionId]           INT            NOT NULL,
    [QueryInstanceOutputSchema]   NVARCHAR (MAX) NULL,
    [QueryInstancetRequestSchema] NVARCHAR (MAX) NULL,
    CONSTRAINT [PKTQueryInstance] PRIMARY KEY CLUSTERED ([QueryInstanceId] ASC),
    CONSTRAINT [FKpTQueryDefinitioncTQueryInstance] FOREIGN KEY ([QueryDefinitionId]) REFERENCES [dbo].[TQueryDefinition] ([QueryDefinitionId])
);

