﻿CREATE TABLE [dbo].[TADFPipelineSchema] (
    [EnvironmentName]   NVARCHAR (20)  NOT NULL,
    [QueryDefinitionId] INT            NOT NULL,
    [ADFPipelineSchema] NVARCHAR (MAX) NOT NULL,
    CONSTRAINT [PKTADFPipelineSchema] PRIMARY KEY CLUSTERED ([EnvironmentName] ASC, [QueryDefinitionId] ASC),
    CONSTRAINT [FKpTEnvironmentReferencecTADFPipelineSchema] FOREIGN KEY ([EnvironmentName]) REFERENCES [dbo].[TEnvironmentReference] ([EnvironmentName]),
    CONSTRAINT [FKpTQueryDefinitioncTADFPipelineSchema] FOREIGN KEY ([QueryDefinitionId]) REFERENCES [dbo].[TQueryDefinition] ([QueryDefinitionId])
);

