﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Models
{
    public class DotNetCoreSettings
    {
        public string ConfigurationFileDev { get; set; } = "appsettings.Development.json";

        public string ConfigurationFileName { get; set; } = "appsettings.json";
    }
}
