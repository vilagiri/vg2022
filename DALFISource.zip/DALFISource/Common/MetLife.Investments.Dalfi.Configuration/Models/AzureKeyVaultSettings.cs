﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Models
{
    public class AzureKeyVaultSettings
    {
        public static string AppSettingUri { get; set; } = "KeyVault-Settings:DnsUri";

        public string DnsUri { get; }

        /// <summary>
        /// to throw runtime exceptions when connecting to key vault set this value to false
        /// </summary>
        public bool IsExceptionsSupressed { get; set; } = false;

        public AzureKeyVaultSettings(String dnsUri)
        {
            this.DnsUri = dnsUri;
        }

        /// <summary>
        /// Factory method to help instantiate AzureKeyVaultSettings
        /// </summary>
        /// <returns></returns>
        public static AzureKeyVaultSettings GetAzureKeyVaultSettings(IConfiguration configuration)
        {
            return new AzureKeyVaultSettings(
                configuration[AppSettingUri]);
        }


    }
}
