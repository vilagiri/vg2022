﻿using MetLife.Investments.Dalfi.Configuration.Interfaces;
using MetLife.Investments.Dalfi.Configuration.Models;
using MetLife.Investments.Dalfi.Configuration.Services;
using MetLife.Investments.Dalfi.Logging.Interfaces;
using MetLife.Investments.Dalfi.Logging.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Extensions
{
    /// <summary>
    /// ServiceCollectionExtensions
    /// </summary>
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddApiClientServices(this IServiceCollection services)
        {
            services.AddScoped<ILoggingService, LoggingService>();
            return services;
        }
        /// <summary>
        /// Add Common Dependency 
        /// </summary>
        public static void AddCommonDependency(this IServiceCollection services)
        {
            services.AddSingleton(AddConfigurationDependency);
        }
        private static IConfigurationService AddConfigurationDependency(IServiceProvider provider)
        {
            var dotNetCoreConfig = new DotNetCoreService();
            AzureKeyVaultSettings keyVaultSettings = AzureKeyVaultSettings.GetAzureKeyVaultSettings(provider.GetRequiredService<IConfiguration>());
            if (!String.IsNullOrWhiteSpace(keyVaultSettings.DnsUri))
            {
                var azureKeyVaultService = new AzureKeyVaultService(keyVaultSettings);
                return new ConfigurationService(dotNetCoreConfig, azureKeyVaultService);
            }
            else
            {
                return new ConfigurationService(dotNetCoreConfig);
            }
        }
    }
}
