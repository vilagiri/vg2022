﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Interfaces
{
    /// <summary>
    /// Source of configuration values at runtime
    /// </summary>
    public interface IConfigurationPlatform
    {
        void Initialize();

        string GetValue(string configurationKeyName);

        IConfigurationSection GetSection(string sectionName);
    }
}
