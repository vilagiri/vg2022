﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Interfaces
{
    public interface IConfigurationService
    {
        T GetValue<T>(string configurationKeyName);

        IConfigurationSection GetSection(string sectionName);
    }
}
