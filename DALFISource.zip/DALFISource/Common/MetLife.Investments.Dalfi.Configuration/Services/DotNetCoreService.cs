﻿using MetLife.Investments.Dalfi.Configuration.Interfaces;
using MetLife.Investments.Dalfi.Configuration.Models;
using Microsoft.Extensions.Configuration;

namespace MetLife.Investments.Dalfi.Configuration.Services
{
    public class DotNetCoreService : IConfigurationPlatform
    {
        private readonly DotNetCoreSettings _settings;

        private IConfiguration _configuration;

        public DotNetCoreService(DotNetCoreSettings settings = default(DotNetCoreSettings))
        {
            _settings = settings ?? new DotNetCoreSettings();
        }

        public void Initialize()
        {
            var configBuilder = new ConfigurationBuilder()
              .AddJsonFile(_settings.ConfigurationFileName, optional: true)
              .AddJsonFile(_settings.ConfigurationFileDev, optional: true);

            _configuration = configBuilder.Build();
        }

        public string GetValue(string configurationKeyName)
        {
            var section = _configuration.GetSection(configurationKeyName);

            return section?.Value;
        }

        public IConfigurationSection GetSection(string sectionName)
        {
            return _configuration.GetSection(sectionName);
        }
    }
}
