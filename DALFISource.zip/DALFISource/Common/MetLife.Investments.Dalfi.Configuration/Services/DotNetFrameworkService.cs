﻿using MetLife.Investments.Dalfi.Configuration.Interfaces;
using Microsoft.Extensions.Configuration;
using System;

namespace MetLife.Investments.Dalfi.Configuration.Services
{
    public class DotNetFrameworkService : IConfigurationPlatform
    {
        public void Initialize()
        {
            throw new NotImplementedException();
        }

        public string GetValue(string configurationKeyName)
        {
            throw new NotImplementedException();
        }

        public IConfigurationSection GetSection(string sectionName)
        {
            throw new NotImplementedException();
        }
    }
}
