﻿using MetLife.Investments.Dalfi.Configuration.Interfaces;
using MetLife.Investments.Dalfi.Configuration.Models;
using Microsoft.Azure.KeyVault;
using Microsoft.Azure.Services.AppAuthentication;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureKeyVault;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace MetLife.Investments.Dalfi.Configuration.Services
{
    public class AzureKeyVaultService : IConfigurationPlatform
    {
        private readonly AzureKeyVaultSettings _settings;

        private IConfiguration _configuration;

        public AzureKeyVaultService(AzureKeyVaultSettings settings)
        {
            _settings = settings;

        }

        public void Initialize()
        {
            var config = new ConfigurationBuilder();
           
                var azureServiceTokenProvider = new AzureServiceTokenProvider();
                var keyVaultClient = new KeyVaultClient(
                    new KeyVaultClient.AuthenticationCallback(
                        azureServiceTokenProvider.KeyVaultTokenCallback));

                config.AddAzureKeyVault(
                   _settings.DnsUri,
                  keyVaultClient,
                  new DefaultKeyVaultSecretManager());


            

            _configuration = config.Build();
        }

        public string GetValue(string configurationKeyName)
        {
            try
            {
                return _configuration.GetSection(configurationKeyName)?.Value;
            }
            catch (Exception ex)
            {
                if (_settings.IsExceptionsSupressed)
                {
                    Trace.TraceError(ex.Message);

                    Trace.TraceError(ex.StackTrace);
                }
                else
                {
                    throw;
                }
            }

            return default(string);
        }

        public IConfigurationSection GetSection(string sectionName)
        {
            try
            {
                return _configuration.GetSection(sectionName);
            }
            catch (Exception ex)
            {
                if (_settings.IsExceptionsSupressed)
                {
                    Trace.TraceError(ex.Message);

                    Trace.TraceError(ex.StackTrace);
                }
                else
                {
                    throw;
                }
            }

            return default(IConfigurationSection);
        }




    }
}
