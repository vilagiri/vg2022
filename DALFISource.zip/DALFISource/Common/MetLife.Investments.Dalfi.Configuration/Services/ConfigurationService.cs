﻿using MetLife.Investments.Dalfi.Configuration.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Linq;

namespace MetLife.Investments.Dalfi.Configuration.Services
{
    public class ConfigurationService : IConfigurationService
    {
        private string _token;
        private readonly IConfigurationPlatform[] _configurationPlatforms;

        /// <summary>
        /// The configuration key is searched for in each of the configuration platforms
        /// The value will be returned from the first source found that contains the key
        /// </summary>
        public ConfigurationService(params IConfigurationPlatform[] platforms)
        {
            _configurationPlatforms = platforms ?? new IConfigurationPlatform[] { };

            _configurationPlatforms.ToList().ForEach(config => config.Initialize());
        }

        public IConfigurationSection GetSection(string sectionName)
        {
            var section = default(IConfigurationSection);

            foreach (var configs in _configurationPlatforms) //check each provider for the value
            {
                section = configs.GetSection(sectionName);

                if (section != null && section.Exists()) { break; }
            }

            return section;
        }

        public string GetToken()
        {
            string token = _token;
            return token;
        }

        public T GetValue<T>(string configurationKeyName)
        {
            var value = this.FindValue(configurationKeyName);

            return this.ConvertValue<T>(value);
        }

        private string FindValue(string configurationKeyName)
        {
            var value = default(string);

            foreach (var configs in _configurationPlatforms) //check each provider for the value
            {
                value = configs.GetValue(configurationKeyName);

                if (value != null) { break; }
            }

            return value;
        }

        private T ConvertValue<T>(string value)
        {
            if (value is null)
            {
                return default(T);
            }
            else if (typeof(T) == typeof(string))
            {
                return (T)(object)value;
            }
            else
            {
                return (T)Convert.ChangeType(value, typeof(T));
            }
        }
    }
}
