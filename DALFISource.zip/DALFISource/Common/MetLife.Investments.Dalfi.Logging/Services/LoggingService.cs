﻿using MetLife.Investments.Dalfi.Logging.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;


namespace MetLife.Investments.Dalfi.Logging.Services
{
    /// <summary>
    /// Wrapper for ILogger 
    /// </summary>
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> logger;

        public LogInfo logInfo;

        private readonly string IsError = "IsError";

        private Dictionary<string, object> scopeColletion;

        public LoggingService(ILogger<LoggingService> logger)
        {
            this.logger = logger;
            this.logInfo = new LogInfo();
            scopeColletion = new Dictionary<string, object>(logInfo.ToObjectDictionary());
        }


        public Dictionary<string, string> AppendLogScopeInfo(Dictionary<string, string> value)
        {
            var scope = GetLogScopeInfo();

            foreach (KeyValuePair<string, string> item in scope)
                value.Add(item.Key, item.Value);

            return value;
        }

        public Dictionary<string, string> GetLogScopeInfo()
        {
            return new Dictionary<string, string>
            {
                [nameof(logInfo.TenantEaicode)] = scopeColletion[nameof(logInfo.TenantEaicode)]?.ToString(),
                [nameof(logInfo.EventId)] = scopeColletion[nameof(logInfo.EventId)]?.ToString(),
                [nameof(logInfo.UserId)] = scopeColletion[nameof(logInfo.UserId)]?.ToString(),
                [nameof(logInfo.ActivityInstanceId)] = scopeColletion[nameof(logInfo.ActivityInstanceId)]?.ToString(),
                [nameof(logInfo.OrchestrationInstanceId)] = scopeColletion[nameof(logInfo.OrchestrationInstanceId)]?.ToString(),
                [nameof(logInfo.ControlInstanceId)] = scopeColletion[nameof(logInfo.ControlInstanceId)]?.ToString()
            };

        }
        /// <summary>
        /// Start a New scope with existing loginfo + new arguments
        /// </summary>
        /// <param name="messageFormat"></param>
        /// <param name="args"></param>
        /// <returns></returns>
        public IDisposable BeginScope(string messageFormat, params object[] args)
        {
            ClearScopeCollection();
            if (this.logInfo != null)
                UpdateScope(GetDictionary(this.logInfo));
            if (args?.Length > 0)
                UpdateScope(args);

            return logger.BeginScope(scopeColletion);
        }


        /// <summary>
        /// Clear all additional scopes and start with existing LogInfo
        /// </summary>
        /// <param name="message"></param>
        public IDisposable BeginScope(string message = null)
        {
            IDisposable id;
            ClearScopeCollection();
            if (this.logInfo != null)
                UpdateScope(GetDictionary(this.logInfo));
            if (message == null) message = "Begin Scope..";
            id = logger.BeginScope(scopeColletion);
            logger.LogInformation(message);
            return id;
        }

        /// <summary>
        /// Add or Update or Remove a scope  parameter (To remove a scope - you can add a 'null' or empty string to the param)
        /// </summary>
        /// <param name="scopeParam">Add New or Upadate existing scope parameter</param>
        /// <param name="value">value of parameter</param>
        public IDisposable AddScope(string scopeParam, string value)
        {
            if (scopeColletion.ContainsKey(scopeParam))
                this.scopeColletion.Remove(scopeParam);

            this.scopeColletion.Add(scopeParam, value);
            return logger.BeginScope(scopeColletion);

        }

        /// <summary>
        /// Add or Update or Remove a scope  object, scope parameter will be the scope object name (To remove a scopeParam -   pass null value as scopeObject)
        /// </summary>
        /// <param name="scopeObject">instance of a serlaizable class object</param>
        public IDisposable AddScopeJson(Object scopeObject)
        {           
            var scopeJson = string.Empty;
            if (scopeObject != null)
            {
                string scopeParam = scopeObject.GetType().Name;
                if (scopeObject.GetType().IsSerializable)
                {
                    scopeJson = JsonConvert.SerializeObject(scopeObject);
                }
                else
                {
                    scopeJson = scopeObject.GetType().Name;
                }

                if (scopeColletion.ContainsKey(scopeParam))
                    this.scopeColletion.Remove(scopeParam);

                this.scopeColletion.Add(scopeParam, scopeJson);
            }
            return logger.BeginScope(scopeColletion);
        }
        /// <summary>
        /// Update existing LogInfo scope
        /// </summary>
        /// <param name="logInfo"></param>
        public IDisposable AddScope(LogInfo loginfo)
        {
            this.logInfo = loginfo;
            this.scopeColletion = GetDictionary(loginfo);
            return logger.BeginScope(scopeColletion);
        }

        /// <summary>
        /// Begin scope with new log info
        /// </summary>
        /// <param name="logMessage"></param>
        /// <param name="logInfo"></param>
        public IDisposable BeginScope(string logMessage, LogInfo loginfo)
        {
            IDisposable id;
            this.logInfo = loginfo;
            ClearScopeCollection();
            UpdateScope(GetDictionary(loginfo));
            using (id = logger.BeginScope(scopeColletion))
            {
                logger.LogInformation(logMessage);
            }
            return id;
        }

        /// <summary>
        /// Begin scope with mandatory params and log information message
        /// </summary>
        /// <param name="logMessage"></param>
        /// <param name="logParams"></param>
        public IDisposable BeginScope(string logMessage, Dictionary<string, object> logParams)
        {
            IDisposable id;
            UpdateScope(logParams);
            using (id = logger.BeginScope(scopeColletion))
            {
                logger.LogInformation(logMessage);
            }
            return id;
        }



        /// <summary>
        /// Begin scope with mandatory params and log information message
        /// </summary>
        /// <param name="logMessage"></param>
        /// <param name="logParams"></param>
        public IDisposable BeginScopeMandatoryParams(string logMessage, Dictionary<string, string> logParams)
        {
            IDisposable id;
            UpdateScopeMandatory(logParams);
            using (id = logger.BeginScope(scopeColletion))
            {
                logger.LogInformation(logMessage);
            }
            return id;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="logParams"></param>
        public IDisposable BeginScope(Dictionary<string, object> logParams)
        {
            UpdateScope(logParams);
            return logger.BeginScope(scopeColletion);


        }
        public void Debug(string message, params object[] args)
        {
            this.AddScope(IsError, "false");
            logger.LogDebug(message, args);
        }

        public void Error(string message, params object[] args)
        {
            this.AddScope(IsError, "true");
            logger.LogError(message, args);
        }

        public void Error(Exception ex, string message, params object[] args)
        {
            this.AddScope(IsError, "true");
            logger.LogError(ex, message, args);
        }

        public void Fatal(string message, params object[] args)
        {
            this.AddScope(IsError, "true");
            logger.LogCritical(message, args);
        }

        public void Fatal(Exception ex, string message, params object[] args)
        {
            this.AddScope(IsError, "true");
            logger.LogCritical(ex, message, args);
        }

        public void Info(string message, params object[] args)
        {
            this.AddScope(IsError, "false");
            logger.LogInformation(message, args);
        }

        public void Trace(string message, params object[] args)
        {
            this.AddScope(IsError, "false");
            logger.LogTrace(message, args);
        }

        public void Warning(string message, params object[] args)
        {
            this.AddScope(IsError, "false");
            logger.LogWarning(message, args);
        }

        public void Warning(Exception ex, string message, params object[] args)
        {
            this.AddScope(IsError, "true");
            logger.LogWarning(ex, message, args);
        }

        Dictionary<string, object> GetDictionary(LogInfo loginfo)
        {
            return new Dictionary<string, object>
            {
                [nameof(loginfo.TenantEaicode)] = loginfo.TenantEaicode,
                [nameof(loginfo.EventId)] = loginfo.EventId,
                [nameof(loginfo.UserId)] = loginfo.UserId,
                [nameof(loginfo.ActivityInstanceId)] = loginfo.ActivityInstanceId,
                [nameof(loginfo.OrchestrationInstanceId)] = loginfo.OrchestrationInstanceId,
                [nameof(loginfo.ControlInstanceId)] = loginfo.ControlInstanceId
            };
        }

        void UpdateScope(params object[] args)
        {
            if (args?.Length > 0)
            {
                foreach (var arg in args)
                    try
                    {
                        this.scopeColletion.Add(arg.ToString(), arg);
                    }
                    catch
                    { //Move on 
                    }
            }
        }
        void UpdateScope(Dictionary<string, object> scopeParams)
        {
            if (scopeParams?.Count > 0)
            {
                foreach (var prm in scopeParams)
                {
                    if (scopeColletion.ContainsKey(prm.Key))
                        scopeColletion.Remove(prm.Key);
                    scopeColletion.Add(prm.Key, prm.Value);
                }
            }
            else
                scopeColletion = scopeParams;
        }


        void UpdateScopeMandatory(Dictionary<string, string> scopeParams)
        {
            if (scopeColletion?.Count > 0)
            {               

                foreach (var prm in scopeParams)
                {
                    if (scopeColletion.ContainsKey(prm.Key))
                    {
                        scopeColletion.Remove(prm.Key);
                    }
                    scopeColletion.Add(prm.Key, prm.Value);
                }
            }
            else
            {
                scopeColletion = new Dictionary<string, object>(logInfo?.ToObjectDictionary());
                foreach (KeyValuePair<string, string> item in scopeParams)
                    scopeColletion.Add(item.Key, item.Value);
            }

        }

        void ClearScopeCollection()
        {
            if (scopeColletion?.Count > 0)
            {
                var newCollection = new Dictionary<string, object>();
                foreach (var v in scopeColletion)
                {
                    newCollection[v.Key] = string.Empty;
                }
                scopeColletion = new Dictionary<string, object>(newCollection);
            }
        }


    }
}
