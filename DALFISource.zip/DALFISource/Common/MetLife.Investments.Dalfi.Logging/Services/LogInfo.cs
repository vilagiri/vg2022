﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Logging.Services
{
    [Serializable]
    public sealed class LogInfo
    {
        public string TenantEaicode { set; get; }
        public string EventId { set; get; }
        public string UserId { set; get; }
        public string ActivityInstanceId { set; get; }
        public string OrchestrationInstanceId { set; get; }
        public string ControlInstanceId { set; get; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="eventid">Event Id</param>
        /// <param name="ActivityInstanceId">Activity ID</param>
        /// <param name="OrchestrationInstanceId">Orachastrator ID</param>
        /// <param name="userid">User Id</param>
        public LogInfo(string tenantEaicode=null, string eventid=null, string activityid =null,string orchestrationInstanceId=null,string userid =null, string controlInstanceId=null)
        {
            TenantEaicode = tenantEaicode;
            EventId = eventid;
            ActivityInstanceId = activityid;
            OrchestrationInstanceId = orchestrationInstanceId; // orch
            UserId = userid;
            ControlInstanceId = controlInstanceId;
        }
        public IDictionary<string, object> ToObjectDictionary()
        {
            return new Dictionary<string, object>
            {
                [nameof(this.TenantEaicode)] = this.TenantEaicode,
                [nameof(this.EventId)] = this.EventId,
                [nameof(this.UserId)] = this.UserId,
                [nameof(this.ActivityInstanceId)] = this.ActivityInstanceId,
                [nameof(this.OrchestrationInstanceId)] = this.OrchestrationInstanceId,
                [nameof(this.ControlInstanceId)] = this.ControlInstanceId
            };

        }



        public override string ToString()
        {
            var sb = new StringBuilder();           
            sb.Append("EventId:").Append(EventId);
            if (string.IsNullOrEmpty(TenantEaicode)) sb.Append(",").Append("TenantEaicode:").Append(TenantEaicode);
            if (string.IsNullOrEmpty(ActivityInstanceId)) sb.Append(",").Append("ActivityInstanceId:").Append(ActivityInstanceId);
            if (string.IsNullOrEmpty(OrchestrationInstanceId)) sb.Append(",").Append("OrchestrationInstanceId:").Append(OrchestrationInstanceId);
            if (string.IsNullOrEmpty(UserId)) sb.Append(",").Append("UserId:").Append(UserId);
            if (string.IsNullOrEmpty(ControlInstanceId)) sb.Append(",").Append("ControlInstanceId:").Append(ControlInstanceId);
            return sb.ToString();
        }
        public IDictionary<string, string> ToDictionary()
        {
            return new Dictionary<string, string>
            {
                [nameof(this.TenantEaicode)] = this.TenantEaicode,
                [nameof(this.EventId)] = this.EventId,
                [nameof(this.UserId)] = this.UserId,
                [nameof(this.ActivityInstanceId)] = this.ActivityInstanceId,
                [nameof(this.OrchestrationInstanceId)] = this.OrchestrationInstanceId,
                [nameof(this.ControlInstanceId)] = this.ControlInstanceId
            };

        }


    }
}
