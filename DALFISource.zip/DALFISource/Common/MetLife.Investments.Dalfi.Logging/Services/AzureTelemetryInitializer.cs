﻿using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Logging.Services
{
    /// <summary>
    /// Azure Telemetry Service
    /// </summary>
    public class AzureTelemetryInitializer : ITelemetryInitializer
    {
        //Constants
        public const string EAICODE = "EAICode";
        public const string SAMPLED = "Sampled";
        public const string APP_NAME = "Application_Name";

        //Properties
        public string ApplicationName { get; set; }
        public string EAICode { get; set; }
        public string Sampled { get; set; }

        //Constructor
        public AzureTelemetryInitializer(string roleName, string eaiCode, bool sampled =true)
        {
            ApplicationName = roleName;
            EAICode = eaiCode;
            Sampled = sampled.ToString();
        }

        /// <summary>
        /// Initialize method implementation
        /// </summary>
        /// <param name="telemetry"></param>
        public void Initialize(ITelemetry telemetry)
        {
            if (!telemetry.Context.GlobalProperties.ContainsKey(APP_NAME))
            {
                telemetry.Context.GlobalProperties.Add(APP_NAME, ApplicationName);
            }

            if (!telemetry.Context.GlobalProperties.ContainsKey(SAMPLED))
            {
                telemetry.Context.GlobalProperties.Add(SAMPLED, Sampled);
            }
            if (!telemetry.Context.GlobalProperties.ContainsKey(EAICODE))
            {
                telemetry.Context.GlobalProperties.Add(EAICODE, EAICode);
            }
        }
    }
}
