﻿using MetLife.Investments.Dalfi.Logging.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace MetLife.Investments.Dalfi.Logging.Interfaces
{
    public interface ILoggingService
    {

        IDisposable BeginScope(string logMessage = null);
        IDisposable BeginScope(string logMessage, LogInfo logInfo);
        IDisposable BeginScope(string messageFormat, params object[] args);
        IDisposable BeginScope(string logMessage, Dictionary<string, object> logParams);
        IDisposable BeginScope(Dictionary<string, object> logParams);
        IDisposable AddScope(string scopeParam, string value);
        IDisposable AddScope(LogInfo logInfo);
        IDisposable AddScopeJson(Object scopeObject);
        void Trace(string message, params object[] args);
        void Info(string message, params object[] args);
        void Debug(string message, params object[] args);
        void Error(string message, params object[] args);
        void Warning(string message, params object[] args);
        void Fatal(string message, params object[] args);
        void Error(Exception ex, string message, params object[] args);
        void Warning(Exception ex, string message, params object[] args);
        void Fatal(Exception ex, string message, params object[] args);
        Dictionary<string, string> GetLogScopeInfo();
        Dictionary<string, string> AppendLogScopeInfo(Dictionary<string, string> value);

        IDisposable BeginScopeMandatoryParams(string logMessage, Dictionary<string, string> logParams);


    }
}
