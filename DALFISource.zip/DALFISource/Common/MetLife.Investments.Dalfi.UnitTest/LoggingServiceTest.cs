﻿using GenFu;
using MetLife.Investments.Dalfi.Logging.Services;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace MetLife.Investments.Dalfi.UnitTest
{
 

    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class LoggerTest
    {
        [TestMethod]
        public void AppendLogScopeInfoTest()
        {
            var iloggerMock = new Mock<ILogger<LoggingService>>();
            var logger = new LoggingService(iloggerMock.Object);
            var Dict = new Dictionary<string, string>();
            Dict.Add("key", "value");
            var result = logger.AppendLogScopeInfo(Dict);
            Assert.AreEqual(result.Count, 7);
        }
        [TestMethod]
        public void BeginScopeTest()
        {
            var iloggerMock = new Mock<ILogger<LoggingService>>();
            var logger = new LoggingService(iloggerMock.Object);
            var Dict = new Dictionary<string, string>();
            Dict.Add("key", "value");
            var log = new LogInfo()
            {
                ActivityInstanceId = "1",
                ControlInstanceId = "1",
                EventId = "1"
            };
            var ObjDict = new Dictionary<string, Object>();
            ObjDict.Add("key", log);
            logger.BeginScope("string", log);
            logger.BeginScope("null");
            logger.BeginScope("string", log, log);
            logger.BeginScope("string", Dict);
            logger.BeginScope(ObjDict);
            var result = logger.BeginScopeMandatoryParams("string", Dict);
            Assert.IsNull(result);
        }

        [TestMethod]
        public void AddScopeTest()
        {
            var iloggerMock = new Mock<ILogger<LoggingService>>();
            var logger = new LoggingService(iloggerMock.Object);
            //var Dict = new Dictionary<string, string>();
            //Dict.Add("key", "value");
            var log = new LogInfo()
            {
                ActivityInstanceId = "1",
                ControlInstanceId = "1",
                EventId = "1"
            };
            logger.AddScope("scopeparam", "value");
            logger.AddScope(log);
            var result = logger.AddScopeJson(log);
            Assert.IsNull(result);
        }
        [TestMethod]
        public void DebugTest()
        {
            try
            {
                var iloggerMock = new Mock<ILogger<LoggingService>>();
                var logger = new LoggingService(iloggerMock.Object);
                //var Dict = new Dictionary<string, string>();
                //Dict.Add("key", "value");
                var log = new LogInfo()
                {
                    ActivityInstanceId = "1",
                    ControlInstanceId = "1",
                    EventId = "1"
                };
                logger.Debug("scopeparam", log, log);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }

        }
        [TestMethod]
        public void ErrorTest()
        {
            try
            {
                var iloggerMock = new Mock<ILogger<LoggingService>>();
                var logger = new LoggingService(iloggerMock.Object);
                //var Dict = new Dictionary<string, string>();
                //Dict.Add("key", "value");
                var log = new LogInfo()
                {
                    ActivityInstanceId = "1",
                    ControlInstanceId = "1",
                    EventId = "1"
                };
                logger.Error("scopeparam", log, log);
                logger.Error(A.New<Exception>(), "scopeparam", log, log);
                logger.Fatal("scopeparam", log, log);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }



        }

        [TestMethod]
        public void InfoTest()
        {
            try
            {
                var iloggerMock = new Mock<ILogger<LoggingService>>();
                var logger = new LoggingService(iloggerMock.Object);
                //var Dict = new Dictionary<string, string>();
                //Dict.Add("key", "value");
                var log = new LogInfo()
                {
                    ActivityInstanceId = "1",
                    ControlInstanceId = "1",
                    EventId = "1"
                };
                logger.Info("scopeparam", log, log);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }

        [TestMethod]
        public void TraceTest()
        {
            try
            {
                var iloggerMock = new Mock<ILogger<LoggingService>>();
                var logger = new LoggingService(iloggerMock.Object);
                //var Dict = new Dictionary<string, string>();
                //Dict.Add("key", "value");
                var log = new LogInfo()
                {
                    ActivityInstanceId = "1",
                    ControlInstanceId = "1",
                    EventId = "1"
                };
                logger.Trace("scopeparam", log, log);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
        [TestMethod]
        public void WarningTest()
        {
            try
            {
                var iloggerMock = new Mock<ILogger<LoggingService>>();
                var logger = new LoggingService(iloggerMock.Object);
                //var Dict = new Dictionary<string, string>();
                //Dict.Add("key", "value");
                var log = new LogInfo()
                {
                    ActivityInstanceId = "1",
                    ControlInstanceId = "1",
                    EventId = "1"
                };
                logger.Warning("scopeparam", log, log);
                logger.Warning(A.New<Exception>(), "string", log, log);
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }


    }
    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class LoginfoTest
    {
        [TestMethod]
        public void logInfoMethod_ToObjectDictionary_Test()
        {
            var log = new LogInfo();
            var dictionary = log.ToObjectDictionary();

            Assert.IsTrue(dictionary.Count == 6);
        }
        [TestMethod]
        public void logInfoMethod_ToString_Test()
        {
            var log = new LogInfo();
            string returnValues = log.ToString();
            var r = 0;
            Assert.IsTrue(returnValues.Contains("EventId"));
        }
        [TestMethod]
        public void logInfoMethod_ToDictionary_Test()
        {
            var log = new LogInfo();
            var dictionary = log.ToDictionary();
            Assert.IsTrue(dictionary.Count == 6);
        }
    }
    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class AzureTelemetryInitializerTest
    {
        [TestMethod]
        public void AzureTelemetryInitializerTestMethod()
        {
            try
            {
                var AzureTelemetryInitializer = new AzureTelemetryInitializer("role", "123");
                Assert.IsTrue(true);
            }
            catch
            {
                Assert.IsTrue(false);
            }
        }
    }
}

