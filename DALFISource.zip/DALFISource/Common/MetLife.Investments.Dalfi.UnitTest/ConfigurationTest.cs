using MetLife.Investments.Dalfi.Configuration.Extensions;
using MetLife.Investments.Dalfi.Configuration.Models;
using MetLife.Investments.Dalfi.Configuration.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Diagnostics.CodeAnalysis;

namespace MetLife.Investments.Dalfi.UnitTest

{
    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class ConfigurationTest
    {
        [TestMethod]
        [ExpectedException(typeof(System.UriFormatException))]
        public void AzureKeyVaultService_Initilize_MethodTest()
        {
            var setting = new Mock<AzureKeyVaultSettings>();
            var azurekeyvault = new AzureKeyVaultService(new AzureKeyVaultSettings(""));
            azurekeyvault.Initialize();
        }

        [TestMethod]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void AzureKeyVaultService_GetValueReturnsNUll()
        {
            var azurekeyvault = new AzureKeyVaultService(new AzureKeyVaultSettings(""));
            Assert.IsNotNull(azurekeyvault.GetValue("key"));
        }

        [TestMethod]
        // [ExpectedException(typeof(System.NullReferenceException))]
        public void AzureKeyVaultService_GetValueTest()
        {
            var azurekeyvault = new AzureKeyVaultService(new AzureKeyVaultSettings("") { IsExceptionsSupressed = true });

            try
            {
                azurekeyvault.GetValue("key");
            }

            catch (Exception ex)
            {
                Assert.Fail();
            }
        }

        [TestMethod]
        //[ExpectedException(typeof(System.NullReferenceException))]
        public void AzureKeyVaultService_GetSectionTest()
        {
            var azurekeyvault = new AzureKeyVaultService(new AzureKeyVaultSettings("") { IsExceptionsSupressed = true });

            azurekeyvault.GetSection("key");
        }

        [TestMethod]
        [ExpectedException(typeof(System.NullReferenceException))]
        public void AzureKeyVaultService_GetSectionReturnsNUll()
        {
            var azurekeyvault = new AzureKeyVaultService(new AzureKeyVaultSettings(""));

            Assert.IsNotNull(azurekeyvault.GetSection("key"));
        }


    }
    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class ConfigurationserviceTest
    {
        [TestMethod]

        public void ConfigurationServiceTest()
        {

            var conf = new ConfigurationService();
            conf.GetSection("key");
            conf.GetToken();
            var result = conf.GetValue<ConfigurationService>("key");
            Assert.IsNull(result);
        }

    }

    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class dotnetcoreserviceTest
    {
        [TestMethod]
        public void dotnetcoreServiceTest()
        {
            var dotnetcoreService = new DotNetCoreService(new DotNetCoreSettings());
            dotnetcoreService.Initialize();
            dotnetcoreService.GetValue("key");
            var result = dotnetcoreService.GetSection("key");
            Assert.IsNotNull(result);
        }
    }

    [TestClass]
    [ExcludeFromCodeCoverageAttribute]

    public class dotnetFrameworkserviceTest
    {
        [TestMethod]
        [ExpectedException(typeof(System.NotImplementedException))]

        public void GetSectionTest()
        {
            var dotnetcoreService = new DotNetFrameworkService();
            dotnetcoreService.GetSection("key");
        }
        [TestMethod]
        [ExpectedException(typeof(System.NotImplementedException))]

        public void InitiazeTest()
        {
            var dotnetcoreService = new DotNetFrameworkService();
            dotnetcoreService.Initialize();

        }
        [TestMethod]
        [ExpectedException(typeof(System.NotImplementedException))]
        public void GetValueTest()
        {
            var dotnetcoreService = new DotNetFrameworkService();
            dotnetcoreService.GetValue("key");
        }
    }
}


