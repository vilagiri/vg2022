using System;
using System.Collections.Generic;
using MetLife.Investments.Dalfi.Api.Client.Model;
using RestSharp;
using ResponseStatus = MetLife.Investments.Dalfi.Api.Client.Model.ResponseStatus;
using MetLife.Investments.Dalfi.Api.Client.Client;

namespace MetLife.Investments.Dalfi.Api.Client.Api
{
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public interface IGridDALApi
    {
        /// <summary>
        /// Insert data to QueryReadiness table Insert data to QueryReadiness table
        /// </summary>
        /// <param name="body">The request body for the Query Readiness Data</param>
        /// <returns>ResponseStatus</returns>
        ResponseStatus InsertQueryReadinessData (EventMessage body);
        /// <summary>
        /// Retrieves file from REST endpoint or Source folder location &amp; place the file in a target folder location Retrieves file from REST endpoint or Source folder location &amp; place the file in a target folder location
        /// </summary>
        /// <param name="body">The request body for the Input Query</param>
        /// <returns>Output</returns>
        Output Run (InputQuery body);
        /// <summary>
        /// To test gridal auth using cert To test gridal auth using cert
        /// </summary>
        /// <returns>string</returns>
     //   string TestAuthorisation ();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="basePath"></param>
        void SetBasePath(String basePath);
    }
  
    /// <summary>
    /// Represents a collection of functions to interact with the API endpoints
    /// </summary>
    public class GridDALApi : IGridDALApi
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GridDALApi"/> class.
        /// </summary>
        /// <param name="apiClient"> an instance of ApiClient (optional)</param>
        /// <returns></returns>
        public GridDALApi(ApiClient apiClient = null)
        {
            if (apiClient == null) // use the default one in Configuration
                this.ApiClient = Configuration.DefaultApiClient; 
            else
                this.ApiClient = apiClient;
        }
    
        /// <summary>
        /// Initializes a new instance of the <see cref="GridDALApi"/> class.
        /// </summary>
        /// <returns></returns>
        public GridDALApi(String basePath)
        {
            this.ApiClient = new ApiClient(basePath);
        }

        /// <summary>
        /// SetBasePath
        /// </summary>
        /// <param name="basePath"></param>
        /// <param name="accessToken"></param>
        public void SetBasePath(String basePath)
        {
            //this.ApiClient.BasePath = basePath;
            this.ApiClient = new ApiClient(basePath);
        }

        /// <summary>
        /// Gets the base path of the API client.
        /// </summary>
        /// <param name="basePath">The base path</param>
        /// <value>The base path</value>
        public String GetBasePath(String basePath)
        {
            return this.ApiClient.BasePath;
        }
    
        /// <summary>
        /// Gets or sets the API client.
        /// </summary>
        /// <value>An instance of the ApiClient</value>
        public ApiClient ApiClient {get; set;}
    
        /// <summary>
        /// Insert data to QueryReadiness table Insert data to QueryReadiness table
        /// </summary>
        /// <param name="body">The request body for the Query Readiness Data</param>
        /// <returns>ResponseStatus</returns>
        public ResponseStatus InsertQueryReadinessData (EventMessage body)
        {
    
            var path = "/v1/GridDAL/InsertQueryReadinessData";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
             postBody = ApiClient.Serialize(body); // http body (model) parameter

            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling InsertQueryReadinessData: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling InsertQueryReadinessData: " + response.ErrorMessage, response.ErrorMessage);
    
            return (ResponseStatus) ApiClient.Deserialize(response.Content, typeof(ResponseStatus), response.Headers);
        }
    
        /// <summary>
        /// Retrieves file from REST endpoint or Source folder location &amp; place the file in a target folder location Retrieves file from REST endpoint or Source folder location &amp; place the file in a target folder location
        /// </summary>
        /// <param name="body">The request body for the Input Query</param>
        /// <returns>Output</returns>
        public Output Run (InputQuery body)
        {
    
            var path = "/v1/GridDAL/InvokeDataBricks";
            path = path.Replace("{format}", "json");
                
            var queryParams = new Dictionary<String, String>();
            var headerParams = new Dictionary<String, String>();
            var formParams = new Dictionary<String, String>();
            var fileParams = new Dictionary<String, FileParameter>();
            String postBody = null;
    
                                    postBody = ApiClient.Serialize(body); // http body (model) parameter

            // authentication setting, if any
            String[] authSettings = new String[] {  };
    
            // make the HTTP request
            IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.POST, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
            if (((int)response.StatusCode) >= 400)
                throw new ApiException ((int)response.StatusCode, "Error calling Run: " + response.Content, response.Content);
            else if (((int)response.StatusCode) == 0)
                throw new ApiException ((int)response.StatusCode, "Error calling Run: " + response.ErrorMessage, response.ErrorMessage);
    
            return (Output) ApiClient.Deserialize(response.Content, typeof(Output), response.Headers);
        }
    
        /// <summary>
        /// To test gridal auth using cert To test gridal auth using cert
        /// </summary>
        /// <returns>string</returns>
        //public string TestAuthorisation ()
        //{
    
        //    var path = "/v1/GridDAL/TestAuthorisation";
        //    path = path.Replace("{format}", "json");
                
        //    var queryParams = new Dictionary<String, String>();
        //    var headerParams = new Dictionary<String, String>();
        //    var formParams = new Dictionary<String, String>();
        //    var fileParams = new Dictionary<String, FileParameter>();
        //    String postBody = null;
    
                                    
        //    // authentication setting, if any
        //    String[] authSettings = new String[] {  };
    
        //    // make the HTTP request
        //    IRestResponse response = (IRestResponse) ApiClient.CallApi(path, Method.GET, queryParams, postBody, headerParams, formParams, fileParams, authSettings);
    
        //    if (((int)response.StatusCode) >= 400)
        //        throw new ApiException ((int)response.StatusCode, "Error calling TestAuthorisation: " + response.Content, response.Content);
        //    else if (((int)response.StatusCode) == 0)
        //        throw new ApiException ((int)response.StatusCode, "Error calling TestAuthorisation: " + response.ErrorMessage, response.ErrorMessage);
    
        //    return (string) ApiClient.Deserialize(response.Content, typeof(string), response.Headers);
        //}
    
    }
}
