using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QueryInstance {
    /// <summary>
    /// Parameter tag name.
    /// </summary>
    /// <value>Parameter tag name.</value>
    [DataMember(Name="QueryInstanceId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceId")]
    public int? QueryInstanceId { get; set; }

    /// <summary>
    /// Gets or Sets QueryInstanceInputSchema
    /// </summary>
    [DataMember(Name="QueryInstanceInputSchema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceInputSchema")]
    public InputQuery QueryInstanceInputSchema { get; set; }

    /// <summary>
    /// Gets or Sets QueryDefinition
    /// </summary>
    [DataMember(Name="QueryDefinition", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryDefinition")]
    public QueryDefinition QueryDefinition { get; set; }

    /// <summary>
    /// Gets or Sets QueryInstanceOutputSchema
    /// </summary>
    [DataMember(Name="QueryInstanceOutputSchema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceOutputSchema")]
    public QueryOutput QueryInstanceOutputSchema { get; set; }

    /// <summary>
    /// Gets or Sets QueryInstanceRequestSchema
    /// </summary>
    [DataMember(Name="QueryInstanceRequestSchema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceRequestSchema")]
    public QueryRequestSchema QueryInstanceRequestSchema { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QueryInstance {\n");
      sb.Append("  QueryInstanceId: ").Append(QueryInstanceId).Append("\n");
      sb.Append("  QueryInstanceInputSchema: ").Append(QueryInstanceInputSchema).Append("\n");
      sb.Append("  QueryDefinition: ").Append(QueryDefinition).Append("\n");
      sb.Append("  QueryInstanceOutputSchema: ").Append(QueryInstanceOutputSchema).Append("\n");
      sb.Append("  QueryInstanceRequestSchema: ").Append(QueryInstanceRequestSchema).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
