using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class InputQuery {
    /// <summary>
    /// Query name
    /// </summary>
    /// <value>Query name</value>
    [DataMember(Name="query", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "query")]
    public string Query { get; set; }

    /// <summary>
    /// A unique id for activity template
    /// </summary>
    /// <value>A unique id for activity template</value>
    [DataMember(Name="as_of_date", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "as_of_date")]
    public string AsOfDate { get; set; }

    /// <summary>
    /// region of data
    /// </summary>
    /// <value>region of data</value>
    [DataMember(Name="region", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "region")]
    public string Region { get; set; }

    /// <summary>
    /// frequency of data
    /// </summary>
    /// <value>frequency of data</value>
    [DataMember(Name="period", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "period")]
    public string Period { get; set; }

    /// <summary>
    /// frequency of data
    /// </summary>
    /// <value>frequency of data</value>
    [DataMember(Name="forcererun", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "forcererun")]
    public string Forcererun { get; set; }

    /// <summary>
    /// Application Eaicode
    /// </summary>
    /// <value>Application Eaicode</value>
    [DataMember(Name="eaicode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "eaicode")]
    public string Eaicode { get; set; }

    /// <summary>
    /// Application Eaicode
    /// </summary>
    /// <value>Application Eaicode</value>
    [DataMember(Name="deliveryOption", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "deliveryOption")]
    public string DeliveryOption { get; set; }

    /// <summary>
    /// Application Eaicode
    /// </summary>
    /// <value>Application Eaicode</value>
    [DataMember(Name="activityInstanceId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "activityInstanceId")]
    public string ActivityInstanceId { get; set; }

    /// <summary>
    /// Application Eaicode
    /// </summary>
    /// <value>Application Eaicode</value>
    [DataMember(Name="orchestrationInstanceId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "orchestrationInstanceId")]
    public string OrchestrationInstanceId { get; set; }

    /// <summary>
    /// Gets or Sets Parameters
    /// </summary>
    [DataMember(Name="Parameters", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Parameters")]
    public List<QueryInputParameter> Parameters { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class InputQuery {\n");
      sb.Append("  Query: ").Append(Query).Append("\n");
      sb.Append("  AsOfDate: ").Append(AsOfDate).Append("\n");
      sb.Append("  Region: ").Append(Region).Append("\n");
      sb.Append("  Period: ").Append(Period).Append("\n");
      sb.Append("  Forcererun: ").Append(Forcererun).Append("\n");
      sb.Append("  Eaicode: ").Append(Eaicode).Append("\n");
      sb.Append("  DeliveryOption: ").Append(DeliveryOption).Append("\n");
      sb.Append("  ActivityInstanceId: ").Append(ActivityInstanceId).Append("\n");
      sb.Append("  OrchestrationInstanceId: ").Append(OrchestrationInstanceId).Append("\n");
      sb.Append("  Parameters: ").Append(Parameters).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
