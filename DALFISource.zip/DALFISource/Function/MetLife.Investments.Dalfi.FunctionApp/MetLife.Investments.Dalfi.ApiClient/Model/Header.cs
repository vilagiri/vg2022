using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Header {
    /// <summary>
    /// Gets or Sets DataClass
    /// </summary>
    [DataMember(Name="DataClass", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DataClass")]
    public string DataClass { get; set; }

    /// <summary>
    /// Gets or Sets DataSetType
    /// </summary>
    [DataMember(Name="DataSetType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DataSetType")]
    public string DataSetType { get; set; }

    /// <summary>
    /// Gets or Sets Region
    /// </summary>
    [DataMember(Name="Region", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Region")]
    public string Region { get; set; }

    /// <summary>
    /// Gets or Sets Period
    /// </summary>
    [DataMember(Name="Period", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Period")]
    public string Period { get; set; }

    /// <summary>
    /// Gets or Sets Schema
    /// </summary>
    [DataMember(Name="Schema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Schema")]
    public string Schema { get; set; }

    /// <summary>
    /// Gets or Sets Source
    /// </summary>
    [DataMember(Name="Source", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Source")]
    public string Source { get; set; }

    /// <summary>
    /// Gets or Sets Operation
    /// </summary>
    [DataMember(Name="Operation", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Operation")]
    public string Operation { get; set; }

    /// <summary>
    /// Gets or Sets Count
    /// </summary>
    [DataMember(Name="Count", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Count")]
    public string Count { get; set; }

    /// <summary>
    /// Gets or Sets AsOfDate
    /// </summary>
    [DataMember(Name="AsOfDate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "AsOfDate")]
    public string AsOfDate { get; set; }

    /// <summary>
    /// Gets or Sets RunTime
    /// </summary>
    [DataMember(Name="RunTime", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RunTime")]
    public string RunTime { get; set; }

    /// <summary>
    /// Gets or Sets Keys
    /// </summary>
    [DataMember(Name="Keys", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Keys")]
    public List<string> Keys { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Header {\n");
      sb.Append("  DataClass: ").Append(DataClass).Append("\n");
      sb.Append("  DataSetType: ").Append(DataSetType).Append("\n");
      sb.Append("  Region: ").Append(Region).Append("\n");
      sb.Append("  Period: ").Append(Period).Append("\n");
      sb.Append("  Schema: ").Append(Schema).Append("\n");
      sb.Append("  Source: ").Append(Source).Append("\n");
      sb.Append("  Operation: ").Append(Operation).Append("\n");
      sb.Append("  Count: ").Append(Count).Append("\n");
      sb.Append("  AsOfDate: ").Append(AsOfDate).Append("\n");
      sb.Append("  RunTime: ").Append(RunTime).Append("\n");
      sb.Append("  Keys: ").Append(Keys).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
