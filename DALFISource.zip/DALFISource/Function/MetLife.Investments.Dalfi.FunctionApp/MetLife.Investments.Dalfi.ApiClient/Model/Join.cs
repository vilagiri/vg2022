using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class Join {
    /// <summary>
    /// Parameter tag name.
    /// </summary>
    /// <value>Parameter tag name.</value>
    [DataMember(Name="join", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "join")]
    public string _Join { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="how", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "how")]
    public string How { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="leftDf", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "leftDf")]
    public string LeftDf { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="rightDf", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "rightDf")]
    public string RightDf { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class Join {\n");
      sb.Append("  _Join: ").Append(_Join).Append("\n");
      sb.Append("  How: ").Append(How).Append("\n");
      sb.Append("  LeftDf: ").Append(LeftDf).Append("\n");
      sb.Append("  RightDf: ").Append(RightDf).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
