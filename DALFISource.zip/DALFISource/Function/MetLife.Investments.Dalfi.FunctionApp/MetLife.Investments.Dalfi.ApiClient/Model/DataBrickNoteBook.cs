using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class DataBrickNoteBook {
    /// <summary>
    /// Parameter tag name.
    /// </summary>
    /// <value>Parameter tag name.</value>
    [DataMember(Name="DatabrickNotebookId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DatabrickNotebookId")]
    public int? DatabrickNotebookId { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="DatabrickNotebookName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DatabrickNotebookName")]
    public string DatabrickNotebookName { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="EnvironmentName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "EnvironmentName")]
    public string EnvironmentName { get; set; }

    /// <summary>
    /// Gets or Sets DatabrickNotebookSchema
    /// </summary>
    [DataMember(Name="DatabrickNotebookSchema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DatabrickNotebookSchema")]
    public DatabrickNotebookSchema DatabrickNotebookSchema { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class DataBrickNoteBook {\n");
      sb.Append("  DatabrickNotebookId: ").Append(DatabrickNotebookId).Append("\n");
      sb.Append("  DatabrickNotebookName: ").Append(DatabrickNotebookName).Append("\n");
      sb.Append("  EnvironmentName: ").Append(EnvironmentName).Append("\n");
      sb.Append("  DatabrickNotebookSchema: ").Append(DatabrickNotebookSchema).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
