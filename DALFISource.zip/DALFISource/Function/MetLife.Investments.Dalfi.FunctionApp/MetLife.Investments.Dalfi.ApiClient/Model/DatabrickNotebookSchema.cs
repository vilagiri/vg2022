using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class DatabrickNotebookSchema {
    /// <summary>
    /// Detail about the configuration
    /// </summary>
    /// <value>Detail about the configuration</value>
    [DataMember(Name="TemplateType", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "TemplateType")]
    public string TemplateType { get; set; }

    /// <summary>
    /// schema of the worker
    /// </summary>
    /// <value>schema of the worker</value>
    [DataMember(Name="Schema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Schema")]
    public string Schema { get; set; }

    /// <summary>
    /// Gets or Sets Definition
    /// </summary>
    [DataMember(Name="Definition", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Definition")]
    public DatabrickNotebookSchemaDefinition Definition { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class DatabrickNotebookSchema {\n");
      sb.Append("  TemplateType: ").Append(TemplateType).Append("\n");
      sb.Append("  Schema: ").Append(Schema).Append("\n");
      sb.Append("  Definition: ").Append(Definition).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
