using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QueryDefinitionSchema {
    /// <summary>
    /// Gets or Sets Name
    /// </summary>
    [DataMember(Name="name", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    /// <summary>
    /// Gets or Sets Description
    /// </summary>
    [DataMember(Name="description", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "description")]
    public string Description { get; set; }

    /// <summary>
    /// Gets or Sets Parameters
    /// </summary>
    [DataMember(Name="parameters", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "parameters")]
    public List<QueryDefParameter> Parameters { get; set; }

    /// <summary>
    /// Gets or Sets Sources
    /// </summary>
    [DataMember(Name="sources", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "sources")]
    public List<Source> Sources { get; set; }

    /// <summary>
    /// Gets or Sets Filters
    /// </summary>
    [DataMember(Name="filters", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "filters")]
    public List<Filter> Filters { get; set; }

    /// <summary>
    /// Gets or Sets Joins
    /// </summary>
    [DataMember(Name="joins", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "joins")]
    public List<Join> Joins { get; set; }

    /// <summary>
    /// Gets or Sets Outputs
    /// </summary>
    [DataMember(Name="outputs", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "outputs")]
    public List<QueryOutput> Outputs { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QueryDefinitionSchema {\n");
      sb.Append("  Name: ").Append(Name).Append("\n");
      sb.Append("  Description: ").Append(Description).Append("\n");
      sb.Append("  Parameters: ").Append(Parameters).Append("\n");
      sb.Append("  Sources: ").Append(Sources).Append("\n");
      sb.Append("  Filters: ").Append(Filters).Append("\n");
      sb.Append("  Joins: ").Append(Joins).Append("\n");
      sb.Append("  Outputs: ").Append(Outputs).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
