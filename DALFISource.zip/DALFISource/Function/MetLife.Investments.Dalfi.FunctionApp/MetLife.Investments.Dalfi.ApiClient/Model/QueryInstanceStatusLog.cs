using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QueryInstanceStatusLog {
    /// <summary>
    /// Parameter tag name.
    /// </summary>
    /// <value>Parameter tag name.</value>
    [DataMember(Name="QueryInstanceStatusId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceStatusId")]
    public int? QueryInstanceStatusId { get; set; }

    /// <summary>
    /// Detail about the configuration
    /// </summary>
    /// <value>Detail about the configuration</value>
    [DataMember(Name="LogMessage", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "LogMessage")]
    public string LogMessage { get; set; }

    /// <summary>
    /// QueryInstanceId.
    /// </summary>
    /// <value>QueryInstanceId.</value>
    [DataMember(Name="QueryInstanceId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "QueryInstanceId")]
    public int? QueryInstanceId { get; set; }

    /// <summary>
    /// ProcessingStatusName
    /// </summary>
    /// <value>ProcessingStatusName</value>
    [DataMember(Name="ProcessingStatusName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ProcessingStatusName")]
    public string ProcessingStatusName { get; set; }

    /// <summary>
    /// Log Entry Time stamp
    /// </summary>
    /// <value>Log Entry Time stamp</value>
    [DataMember(Name="LogEntryTimestamp", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "LogEntryTimestamp")]
    public string LogEntryTimestamp { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QueryInstanceStatusLog {\n");
      sb.Append("  QueryInstanceStatusId: ").Append(QueryInstanceStatusId).Append("\n");
      sb.Append("  LogMessage: ").Append(LogMessage).Append("\n");
      sb.Append("  QueryInstanceId: ").Append(QueryInstanceId).Append("\n");
      sb.Append("  ProcessingStatusName: ").Append(ProcessingStatusName).Append("\n");
      sb.Append("  LogEntryTimestamp: ").Append(LogEntryTimestamp).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
