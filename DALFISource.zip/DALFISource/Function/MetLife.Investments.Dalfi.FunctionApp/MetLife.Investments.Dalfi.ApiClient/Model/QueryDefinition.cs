using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QueryDefinition {
    /// <summary>
    /// query definitiion id.
    /// </summary>
    /// <value>query definitiion id.</value>
    [DataMember(Name="id", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "id")]
    public string Id { get; set; }

    /// <summary>
    /// Query Definition Name.
    /// </summary>
    /// <value>Query Definition Name.</value>
    [DataMember(Name="queryDefinitionName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "queryDefinitionName")]
    public string QueryDefinitionName { get; set; }

    /// <summary>
    /// Version Code.
    /// </summary>
    /// <value>Version Code.</value>
    [DataMember(Name="VersionCode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VersionCode")]
    public string VersionCode { get; set; }

    /// <summary>
    /// Gets or Sets _QueryDefinition
    /// </summary>
    [DataMember(Name="queryDefinition", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "queryDefinition")]
    public QueryDefinitionSchema _QueryDefinition { get; set; }

    /// <summary>
    /// Version StartDate.
    /// </summary>
    /// <value>Version StartDate.</value>
    [DataMember(Name="VersionStartDate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VersionStartDate")]
    public string VersionStartDate { get; set; }

    /// <summary>
    /// Version EndDate.
    /// </summary>
    /// <value>Version EndDate.</value>
    [DataMember(Name="VersionEndDate", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "VersionEndDate")]
    public string VersionEndDate { get; set; }

    /// <summary>
    /// Default Delivery Method Name.
    /// </summary>
    /// <value>Default Delivery Method Name.</value>
    [DataMember(Name="DefaultDeliveryMethodName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DefaultDeliveryMethodName")]
    public string DefaultDeliveryMethodName { get; set; }

    /// <summary>
    /// Gets or Sets DataBrickNoteBook
    /// </summary>
    [DataMember(Name="DataBrickNoteBook", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "DataBrickNoteBook")]
    public DataBrickNoteBook DataBrickNoteBook { get; set; }

    /// <summary>
    /// Gets or Sets ADFPipeline
    /// </summary>
    [DataMember(Name="ADFPipeline", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ADFPipeline")]
    public ADFPipeline ADFPipeline { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QueryDefinition {\n");
      sb.Append("  Id: ").Append(Id).Append("\n");
      sb.Append("  QueryDefinitionName: ").Append(QueryDefinitionName).Append("\n");
      sb.Append("  VersionCode: ").Append(VersionCode).Append("\n");
      sb.Append("  _QueryDefinition: ").Append(_QueryDefinition).Append("\n");
      sb.Append("  VersionStartDate: ").Append(VersionStartDate).Append("\n");
      sb.Append("  VersionEndDate: ").Append(VersionEndDate).Append("\n");
      sb.Append("  DefaultDeliveryMethodName: ").Append(DefaultDeliveryMethodName).Append("\n");
      sb.Append("  DataBrickNoteBook: ").Append(DataBrickNoteBook).Append("\n");
      sb.Append("  ADFPipeline: ").Append(ADFPipeline).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
