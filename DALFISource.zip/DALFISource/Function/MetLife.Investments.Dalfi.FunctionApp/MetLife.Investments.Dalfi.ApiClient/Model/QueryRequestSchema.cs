using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class QueryRequestSchema {
    /// <summary>
    /// Requested On.
    /// </summary>
    /// <value>Requested On.</value>
    [DataMember(Name="RequestedOn", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RequestedOn")]
    public string RequestedOn { get; set; }

    /// <summary>
    /// Requested By.
    /// </summary>
    /// <value>Requested By.</value>
    [DataMember(Name="RequestedBy", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "RequestedBy")]
    public string RequestedBy { get; set; }

    /// <summary>
    /// Server Name.
    /// </summary>
    /// <value>Server Name.</value>
    [DataMember(Name="Server", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "Server")]
    public string Server { get; set; }

    /// <summary>
    /// eai code.
    /// </summary>
    /// <value>eai code.</value>
    [DataMember(Name="eaicode", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "eaicode")]
    public string Eaicode { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class QueryRequestSchema {\n");
      sb.Append("  RequestedOn: ").Append(RequestedOn).Append("\n");
      sb.Append("  RequestedBy: ").Append(RequestedBy).Append("\n");
      sb.Append("  Server: ").Append(Server).Append("\n");
      sb.Append("  Eaicode: ").Append(Eaicode).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
