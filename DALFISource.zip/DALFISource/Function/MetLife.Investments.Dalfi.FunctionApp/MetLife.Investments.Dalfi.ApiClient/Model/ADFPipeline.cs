using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace MetLife.Investments.Dalfi.Api.Client.Model {

  /// <summary>
  /// 
  /// </summary>
  [DataContract]
  public class ADFPipeline {
    /// <summary>
    /// Parameter tag name.
    /// </summary>
    /// <value>Parameter tag name.</value>
    [DataMember(Name="ADFPipelineId", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ADFPipelineId")]
    public int? ADFPipelineId { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="ADFPipelineName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ADFPipelineName")]
    public string ADFPipelineName { get; set; }

    /// <summary>
    /// Parameter value.
    /// </summary>
    /// <value>Parameter value.</value>
    [DataMember(Name="EnvironmentName", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "EnvironmentName")]
    public string EnvironmentName { get; set; }

    /// <summary>
    /// Gets or Sets ADFPipelineSchema
    /// </summary>
    [DataMember(Name="ADFPipelineSchema", EmitDefaultValue=false)]
    [JsonProperty(PropertyName = "ADFPipelineSchema")]
    public ADFPipelineSchema ADFPipelineSchema { get; set; }


    /// <summary>
    /// Get the string presentation of the object
    /// </summary>
    /// <returns>String presentation of the object</returns>
    public override string ToString()  {
      var sb = new StringBuilder();
      sb.Append("class ADFPipeline {\n");
      sb.Append("  ADFPipelineId: ").Append(ADFPipelineId).Append("\n");
      sb.Append("  ADFPipelineName: ").Append(ADFPipelineName).Append("\n");
      sb.Append("  EnvironmentName: ").Append(EnvironmentName).Append("\n");
      sb.Append("  ADFPipelineSchema: ").Append(ADFPipelineSchema).Append("\n");
      sb.Append("}\n");
      return sb.ToString();
    }

    /// <summary>
    /// Get the JSON string presentation of the object
    /// </summary>
    /// <returns>JSON string presentation of the object</returns>
    public string ToJson() {
      return JsonConvert.SerializeObject(this, Formatting.Indented);
    }

}
}
