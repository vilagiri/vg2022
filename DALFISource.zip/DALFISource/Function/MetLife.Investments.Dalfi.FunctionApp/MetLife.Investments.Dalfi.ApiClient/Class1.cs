﻿using System;

namespace MetLife.Investments.Dalfi.Api.Client
{
    public class Class1
    {
    }
}
